package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/nihil/obsidian-base/internal/base"
	oerr "github.com/nihil/obsidian-base/internal/errors"
	"github.com/nihil/obsidian-base/internal/output"
	"github.com/nihil/obsidian-base/internal/sql"
	"github.com/nihil/obsidian-base/internal/vault"
	"github.com/spf13/cobra"
	"gopkg.in/yaml.v3"
)

var (
	vaultPath  string
	formatStr  string
	rawOutput  bool
	quietMode  bool
	hardDelete bool
	yesFlag    bool
	folderFlag string
)

func main() {
	rootCmd := &cobra.Command{
		Use:   "obsidian-base",
		Short: "Query and manipulate Obsidian Bases from the command line",
		PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
			if vaultPath == "" {
				vaultPath = os.Getenv("OBSIDIAN_VAULT")
			}
			if vaultPath == "" && cmd.Name() != "help" && cmd.Name() != "obsidian-base" {
				return fmt.Errorf("vault path required: use --vault flag or OBSIDIAN_VAULT env var")
			}
			return nil
		},
	}

	rootCmd.PersistentFlags().StringVar(&vaultPath, "vault", "", "path to Obsidian vault root (or set OBSIDIAN_VAULT)")
	rootCmd.PersistentFlags().StringVar(&formatStr, "format", "json", "output format: json, table, csv, yaml")
	rootCmd.PersistentFlags().BoolVar(&rawOutput, "raw", false, "dump raw .base file contents")
	rootCmd.PersistentFlags().BoolVar(&quietMode, "quiet", false, "suppress non-essential output")

	rootCmd.AddCommand(sqlCmd())
	rootCmd.AddCommand(basesCmd())
	rootCmd.AddCommand(describeCmd())
	rootCmd.AddCommand(initCmd())
	rootCmd.AddCommand(alterCmd())

	if err := rootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}

func openVault() *vault.Vault {
	v, err := vault.Open(vaultPath)
	if err != nil {
		oerr.PrintAndExit(oerr.Newf(oerr.VaultNotFound, "cannot open vault: %v", err))
	}
	return v
}

func getFormat() output.Format {
	f, err := output.ParseFormat(formatStr)
	if err != nil {
		oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "invalid format: %s", formatStr))
	}
	return f
}

func emit(data any) {
	f := getFormat()
	if err := output.Write(os.Stdout, f, data); err != nil {
		oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "output error: %v", err))
	}
}

// --- sql command ---

func sqlCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "sql \"<SQL statement>\"",
		Short: "Execute a SQL query against Obsidian Bases",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			v := openVault()

			stmt, err := sql.ParseSQL(args[0])
			if err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "SQL parse error: %v", err))
			}

			executor := &sql.Executor{
				Vault:      v,
				HardDelete: hardDelete,
				Yes:        yesFlag,
				Folder:     folderFlag,
			}

			result, err := executor.Execute(stmt)
			if err != nil {
				if e, ok := err.(*oerr.Error); ok {
					oerr.PrintAndExit(e)
				}
				oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "%v", err))
			}

			if result.Created != "" {
				emit(map[string]string{"created": result.Created})
			} else if result.Updated > 0 {
				emit(map[string]int{"updated": result.Updated})
			} else if result.Deleted > 0 || result.Message != "" {
				out := map[string]any{"deleted": result.Deleted}
				if result.Message != "" {
					out["message"] = result.Message
				}
				emit(out)
			} else {
				emit(result.Rows)
			}
		},
	}

	cmd.Flags().BoolVar(&hardDelete, "hard-delete", false, "actually delete files (default: unlink)")
	cmd.Flags().BoolVar(&yesFlag, "yes", false, "skip confirmation for destructive operations")
	cmd.Flags().StringVar(&folderFlag, "folder", "", "override folder for INSERT operations")

	return cmd
}

// --- bases command ---

func basesCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "bases",
		Short: "List all .base files in the vault",
		Run: func(cmd *cobra.Command, args []string) {
			v := openVault()

			var result []map[string]any
			for _, bp := range v.BaseFiles() {
				b, err := base.Parse(bp)
				if err != nil {
					continue
				}

				relPath, _ := filepath.Rel(v.Root, bp)
				entry := map[string]any{
					"name":  b.Name,
					"path":  relPath,
					"views": len(b.Views),
				}
				if b.Filters != nil {
					entry["filters"] = base.FilterToString(b.Filters)
				}
				result = append(result, entry)
			}

			emit(result)
		},
	}
}

// --- describe command ---

func describeCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "describe <base-name>",
		Short: "Show schema of a base",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			v := openVault()

			basePath := v.FindBase(args[0])
			if basePath == "" {
				names := v.BaseNames()
				oerr.PrintAndExit(oerr.WithSuggestion(oerr.BaseNotFound,
					fmt.Sprintf("no base file named '%s' found", args[0]),
					fmt.Sprintf("available bases: %s", strings.Join(names, ", "))))
			}

			if rawOutput {
				data, err := os.ReadFile(basePath)
				if err != nil {
					oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "failed to read base file: %v", err))
				}
				fmt.Print(string(data))
				return
			}

			b, err := base.Parse(basePath)
			if err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "failed to parse base: %v", err))
			}

			notes := base.Resolve(b, v)
			columns := base.ResolveColumns(b, notes)

			relPath, _ := filepath.Rel(v.Root, basePath)

			// Build views info
			var views []map[string]any
			for _, view := range b.Views {
				vm := map[string]any{
					"name": view.Name,
					"type": view.Type,
				}
				if view.Filters != nil {
					vm["filters"] = base.FilterToString(view.Filters)
				}
				if len(view.Order) > 0 {
					vm["order"] = view.Order
				}
				if view.Limit > 0 {
					vm["limit"] = view.Limit
				}
				views = append(views, vm)
			}

			result := map[string]any{
				"name":              b.Name,
				"path":              relPath,
				"global_filters":    base.FilterToString(b.Filters),
				"formulas":          b.Formulas,
				"columns":           columns,
				"views":             views,
				"summaries":         b.Summaries,
				"properties_config": b.Properties,
				"note_count":        len(notes),
			}

			emit(result)
		},
	}
}

// --- init command ---

func initCmd() *cobra.Command {
	var filterExpr string
	var folder string
	var viewType string

	cmd := &cobra.Command{
		Use:   "init <base-name>",
		Short: "Create a new .base file",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			v := openVault()
			name := args[0]

			// Check if already exists
			if existing := v.FindBase(name); existing != "" {
				oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "base '%s' already exists at %s", name, existing))
			}

			// Build the base YAML
			raw := make(map[string]any)

			if filterExpr != "" {
				raw["filters"] = map[string]any{
					"and": []any{filterExpr},
				}
			}

			vt := "table"
			if viewType != "" {
				vt = viewType
			}
			raw["views"] = []any{
				map[string]any{
					"type": vt,
					"name": "Table",
				},
			}

			data, err := yaml.Marshal(raw)
			if err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "failed to serialize base: %v", err))
			}

			// Determine output path
			dir := v.Root
			if folder != "" {
				dir = filepath.Join(v.Root, folder)
			}
			outPath := filepath.Join(dir, name+".base")

			if err := os.MkdirAll(filepath.Dir(outPath), 0755); err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "failed to create directory: %v", err))
			}
			if err := os.WriteFile(outPath, data, 0644); err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "failed to write base file: %v", err))
			}

			relPath, _ := filepath.Rel(v.Root, outPath)
			emit(map[string]string{"created": relPath})
		},
	}

	cmd.Flags().StringVar(&filterExpr, "filter", "", "global filter expression (Bases syntax)")
	cmd.Flags().StringVar(&folder, "folder", "", "where to create the .base file")
	cmd.Flags().StringVar(&viewType, "type", "table", "default view type: table, list, cards")

	return cmd
}

// --- alter command ---

func alterCmd() *cobra.Command {
	var addFormula string
	var removeFormula string
	var setFilter string
	var addView string
	var removeView string
	var setProperty string
	var addSummary string

	cmd := &cobra.Command{
		Use:   "alter <base-name>",
		Short: "Modify an existing .base file's structure",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			v := openVault()
			basePath := v.FindBase(args[0])
			if basePath == "" {
				names := v.BaseNames()
				oerr.PrintAndExit(oerr.WithSuggestion(oerr.BaseNotFound,
					fmt.Sprintf("no base file named '%s' found", args[0]),
					fmt.Sprintf("available bases: %s", strings.Join(names, ", "))))
			}

			b, err := base.Parse(basePath)
			if err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "failed to parse base: %v", err))
			}

			raw := b.Raw
			modified := false

			// --add-formula 'name: "expression"'
			if addFormula != "" {
				parts := strings.SplitN(addFormula, ":", 2)
				if len(parts) != 2 {
					oerr.PrintAndExit(oerr.New(oerr.ParseError, "formula format: 'name: \"expression\"'"))
				}
				name := strings.TrimSpace(parts[0])
				expression := strings.TrimSpace(parts[1])
				expression = strings.Trim(expression, "\"'")

				formulas, _ := raw["formulas"].(map[string]any)
				if formulas == nil {
					formulas = make(map[string]any)
				}
				formulas[name] = expression
				raw["formulas"] = formulas
				modified = true
			}

			// --remove-formula name
			if removeFormula != "" {
				if formulas, ok := raw["formulas"].(map[string]any); ok {
					delete(formulas, removeFormula)
					if len(formulas) == 0 {
						delete(raw, "formulas")
					}
				}
				modified = true
			}

			// --set-filter 'expression'
			if setFilter != "" {
				raw["filters"] = map[string]any{
					"and": []any{setFilter},
				}
				modified = true
			}

			// --add-view '{"type":"cards","name":"Gallery"}'
			if addView != "" {
				var viewConfig map[string]any
				if err := json.Unmarshal([]byte(addView), &viewConfig); err != nil {
					oerr.PrintAndExit(oerr.Newf(oerr.ParseError, "invalid view JSON: %v", err))
				}
				views, _ := raw["views"].([]any)
				views = append(views, viewConfig)
				raw["views"] = views
				modified = true
			}

			// --remove-view "Gallery"
			if removeView != "" {
				if views, ok := raw["views"].([]any); ok {
					var newViews []any
					for _, v := range views {
						if vm, ok := v.(map[string]any); ok {
							if name, ok := vm["name"].(string); ok && name == removeView {
								continue
							}
						}
						newViews = append(newViews, v)
					}
					raw["views"] = newViews
				}
				modified = true
			}

			// --set-property 'rating:displayName=Stars'
			if setProperty != "" {
				parts := strings.SplitN(setProperty, ":", 2)
				if len(parts) != 2 {
					oerr.PrintAndExit(oerr.New(oerr.ParseError, "property format: 'name:key=value'"))
				}
				propName := "note." + strings.TrimSpace(parts[0])
				kv := strings.SplitN(parts[1], "=", 2)
				if len(kv) != 2 {
					oerr.PrintAndExit(oerr.New(oerr.ParseError, "property format: 'name:key=value'"))
				}

				props, _ := raw["properties"].(map[string]any)
				if props == nil {
					props = make(map[string]any)
				}
				propConfig, _ := props[propName].(map[string]any)
				if propConfig == nil {
					propConfig = make(map[string]any)
				}
				propConfig[strings.TrimSpace(kv[0])] = strings.TrimSpace(kv[1])
				props[propName] = propConfig
				raw["properties"] = props
				modified = true
			}

			// --add-summary 'name: Type'
			if addSummary != "" {
				parts := strings.SplitN(addSummary, ":", 2)
				if len(parts) != 2 {
					oerr.PrintAndExit(oerr.New(oerr.ParseError, "summary format: 'name: Type'"))
				}
				summaries, _ := raw["summaries"].(map[string]any)
				if summaries == nil {
					summaries = make(map[string]any)
				}
				summaries[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
				raw["summaries"] = summaries
				modified = true
			}

			if !modified {
				fmt.Fprintln(os.Stderr, "no modifications specified")
				os.Exit(1)
			}

			data, err := yaml.Marshal(raw)
			if err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "failed to serialize: %v", err))
			}
			if err := os.WriteFile(basePath, data, 0644); err != nil {
				oerr.PrintAndExit(oerr.Newf(oerr.WriteError, "failed to write: %v", err))
			}

			if !quietMode {
				emit(map[string]string{"modified": args[0]})
			}
		},
	}

	cmd.Flags().StringVar(&addFormula, "add-formula", "", "add a formula: 'name: \"expression\"'")
	cmd.Flags().StringVar(&removeFormula, "remove-formula", "", "remove a formula by name")
	cmd.Flags().StringVar(&setFilter, "set-filter", "", "set the global filter expression")
	cmd.Flags().StringVar(&addView, "add-view", "", "add a view (JSON)")
	cmd.Flags().StringVar(&removeView, "remove-view", "", "remove a view by name")
	cmd.Flags().StringVar(&setProperty, "set-property", "", "set a property config: 'name:key=value'")
	cmd.Flags().StringVar(&addSummary, "add-summary", "", "add a summary: 'name: Type'")

	return cmd
}
