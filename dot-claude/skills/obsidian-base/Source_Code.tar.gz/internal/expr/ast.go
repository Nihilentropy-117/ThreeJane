package expr

// Node is the AST node interface.
type Node interface {
	nodeType() string
}

// NumberLit represents a numeric literal.
type NumberLit struct {
	Value float64
}

func (n *NumberLit) nodeType() string { return "number" }

// StringLit represents a string literal.
type StringLit struct {
	Value string
}

func (n *StringLit) nodeType() string { return "string" }

// BoolLit represents a boolean literal.
type BoolLit struct {
	Value bool
}

func (n *BoolLit) nodeType() string { return "bool" }

// NullLit represents a null literal.
type NullLit struct{}

func (n *NullLit) nodeType() string { return "null" }

// RegexLit represents a regex literal.
type RegexLit struct {
	Pattern string
}

func (n *RegexLit) nodeType() string { return "regex" }

// Ident represents an identifier (variable/property reference).
type Ident struct {
	Name string
}

func (n *Ident) nodeType() string { return "ident" }

// BinaryExpr represents a binary operation.
type BinaryExpr struct {
	Op    string
	Left  Node
	Right Node
}

func (n *BinaryExpr) nodeType() string { return "binary" }

// UnaryExpr represents a unary operation.
type UnaryExpr struct {
	Op      string
	Operand Node
}

func (n *UnaryExpr) nodeType() string { return "unary" }

// MemberExpr represents property access (obj.prop).
type MemberExpr struct {
	Object   Node
	Property string
}

func (n *MemberExpr) nodeType() string { return "member" }

// IndexExpr represents index access (obj[expr]).
type IndexExpr struct {
	Object Node
	Index  Node
}

func (n *IndexExpr) nodeType() string { return "index" }

// CallExpr represents a function call (fn(args...)).
type CallExpr struct {
	Function Node
	Args     []Node
}

func (n *CallExpr) nodeType() string { return "call" }

// MethodExpr represents a method call (obj.method(args...)).
type MethodExpr struct {
	Object Node
	Method string
	Args   []Node
}

func (n *MethodExpr) nodeType() string { return "method" }

// ListExpr represents a list literal [a, b, c].
type ListExpr struct {
	Items []Node
}

func (n *ListExpr) nodeType() string { return "list" }

// ObjectExpr represents an object literal {"a": 1, "b": 2}.
type ObjectExpr struct {
	Keys   []string
	Values []Node
}

func (n *ObjectExpr) nodeType() string { return "object" }

// TernaryExpr represents condition ? then : else.
type TernaryExpr struct {
	Condition Node
	Then      Node
	Else      Node
}

func (n *TernaryExpr) nodeType() string { return "ternary" }

// LambdaExpr represents an expression used as a lambda in filter/map/reduce.
// The parameter name is implicitly the current item.
type LambdaExpr struct {
	Expr Node
}

func (n *LambdaExpr) nodeType() string { return "lambda" }
