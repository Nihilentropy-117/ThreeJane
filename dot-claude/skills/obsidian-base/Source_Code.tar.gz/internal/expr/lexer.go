package expr

import (
	"fmt"
	"strings"
	"unicode"
)

type TokenType int

const (
	// Literals
	TokNumber TokenType = iota
	TokString
	TokTrue
	TokFalse
	TokNull
	TokIdent
	TokRegex

	// Operators
	TokPlus
	TokMinus
	TokStar
	TokSlash
	TokPercent
	TokEq
	TokNeq
	TokLt
	TokLte
	TokGt
	TokGte
	TokAnd
	TokOr
	TokNot
	TokDot
	TokComma
	TokColon
	TokQuestion

	// Delimiters
	TokLParen
	TokRParen
	TokLBracket
	TokRBracket
	TokLBrace
	TokRBrace

	TokEOF
)

var tokenNames = map[TokenType]string{
	TokNumber: "NUMBER", TokString: "STRING", TokTrue: "TRUE", TokFalse: "FALSE",
	TokNull: "NULL", TokIdent: "IDENT", TokRegex: "REGEX",
	TokPlus: "+", TokMinus: "-", TokStar: "*", TokSlash: "/", TokPercent: "%",
	TokEq: "==", TokNeq: "!=", TokLt: "<", TokLte: "<=", TokGt: ">", TokGte: ">=",
	TokAnd: "&&", TokOr: "||", TokNot: "!", TokDot: ".", TokComma: ",",
	TokColon: ":", TokQuestion: "?",
	TokLParen: "(", TokRParen: ")", TokLBracket: "[", TokRBracket: "]",
	TokLBrace: "{", TokRBrace: "}",
	TokEOF: "EOF",
}

type Token struct {
	Type TokenType
	Val  string
	Pos  int
}

func (t Token) String() string {
	name := tokenNames[t.Type]
	if t.Val != "" && t.Type != TokEOF {
		return fmt.Sprintf("%s(%s)", name, t.Val)
	}
	return name
}

type Lexer struct {
	input  string
	pos    int
	tokens []Token
}

func NewLexer(input string) *Lexer {
	return &Lexer{input: input}
}

func (l *Lexer) Tokenize() ([]Token, error) {
	for l.pos < len(l.input) {
		l.skipWhitespace()
		if l.pos >= len(l.input) {
			break
		}

		ch := l.input[l.pos]

		switch {
		case ch == '/' && l.pos+1 < len(l.input) && l.isRegexContext():
			tok, err := l.readRegex()
			if err != nil {
				return nil, err
			}
			l.tokens = append(l.tokens, tok)
		case ch >= '0' && ch <= '9':
			l.tokens = append(l.tokens, l.readNumber())
		case ch == '"' || ch == '\'':
			tok, err := l.readString()
			if err != nil {
				return nil, err
			}
			l.tokens = append(l.tokens, tok)
		case isIdentStart(ch):
			l.tokens = append(l.tokens, l.readIdent())
		case ch == '+':
			l.tokens = append(l.tokens, Token{TokPlus, "+", l.pos})
			l.pos++
		case ch == '-':
			l.tokens = append(l.tokens, Token{TokMinus, "-", l.pos})
			l.pos++
		case ch == '*':
			l.tokens = append(l.tokens, Token{TokStar, "*", l.pos})
			l.pos++
		case ch == '/':
			l.tokens = append(l.tokens, Token{TokSlash, "/", l.pos})
			l.pos++
		case ch == '%':
			l.tokens = append(l.tokens, Token{TokPercent, "%", l.pos})
			l.pos++
		case ch == '=' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokEq, "==", l.pos})
			l.pos += 2
		case ch == '!' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokNeq, "!=", l.pos})
			l.pos += 2
		case ch == '!':
			l.tokens = append(l.tokens, Token{TokNot, "!", l.pos})
			l.pos++
		case ch == '<' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokLte, "<=", l.pos})
			l.pos += 2
		case ch == '<':
			l.tokens = append(l.tokens, Token{TokLt, "<", l.pos})
			l.pos++
		case ch == '>' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokGte, ">=", l.pos})
			l.pos += 2
		case ch == '>':
			l.tokens = append(l.tokens, Token{TokGt, ">", l.pos})
			l.pos++
		case ch == '&' && l.peek(1) == '&':
			l.tokens = append(l.tokens, Token{TokAnd, "&&", l.pos})
			l.pos += 2
		case ch == '|' && l.peek(1) == '|':
			l.tokens = append(l.tokens, Token{TokOr, "||", l.pos})
			l.pos += 2
		case ch == '.':
			l.tokens = append(l.tokens, Token{TokDot, ".", l.pos})
			l.pos++
		case ch == ',':
			l.tokens = append(l.tokens, Token{TokComma, ",", l.pos})
			l.pos++
		case ch == ':':
			l.tokens = append(l.tokens, Token{TokColon, ":", l.pos})
			l.pos++
		case ch == '?':
			l.tokens = append(l.tokens, Token{TokQuestion, "?", l.pos})
			l.pos++
		case ch == '(':
			l.tokens = append(l.tokens, Token{TokLParen, "(", l.pos})
			l.pos++
		case ch == ')':
			l.tokens = append(l.tokens, Token{TokRParen, ")", l.pos})
			l.pos++
		case ch == '[':
			l.tokens = append(l.tokens, Token{TokLBracket, "[", l.pos})
			l.pos++
		case ch == ']':
			l.tokens = append(l.tokens, Token{TokRBracket, "]", l.pos})
			l.pos++
		case ch == '{':
			l.tokens = append(l.tokens, Token{TokLBrace, "{", l.pos})
			l.pos++
		case ch == '}':
			l.tokens = append(l.tokens, Token{TokRBrace, "}", l.pos})
			l.pos++
		default:
			return nil, fmt.Errorf("unexpected character '%c' at position %d", ch, l.pos)
		}
	}

	l.tokens = append(l.tokens, Token{TokEOF, "", l.pos})
	return l.tokens, nil
}

func (l *Lexer) skipWhitespace() {
	for l.pos < len(l.input) && (l.input[l.pos] == ' ' || l.input[l.pos] == '\t' || l.input[l.pos] == '\n' || l.input[l.pos] == '\r') {
		l.pos++
	}
}

func (l *Lexer) peek(offset int) byte {
	idx := l.pos + offset
	if idx < len(l.input) {
		return l.input[idx]
	}
	return 0
}

func (l *Lexer) isRegexContext() bool {
	// A slash starts a regex if:
	// - It's at the start of the expression
	// - The previous token is an operator, opening bracket/paren, or comma
	if len(l.tokens) == 0 {
		return true
	}
	prev := l.tokens[len(l.tokens)-1].Type
	switch prev {
	case TokPlus, TokMinus, TokStar, TokSlash, TokPercent,
		TokEq, TokNeq, TokLt, TokLte, TokGt, TokGte,
		TokAnd, TokOr, TokNot,
		TokLParen, TokLBracket, TokComma, TokColon:
		return true
	}
	return false
}

func (l *Lexer) readNumber() Token {
	start := l.pos
	for l.pos < len(l.input) && (l.input[l.pos] >= '0' && l.input[l.pos] <= '9') {
		l.pos++
	}
	if l.pos < len(l.input) && l.input[l.pos] == '.' {
		l.pos++
		for l.pos < len(l.input) && (l.input[l.pos] >= '0' && l.input[l.pos] <= '9') {
			l.pos++
		}
	}
	return Token{TokNumber, l.input[start:l.pos], start}
}

func (l *Lexer) readString() (Token, error) {
	quote := l.input[l.pos]
	start := l.pos
	l.pos++ // skip opening quote

	var sb strings.Builder
	for l.pos < len(l.input) {
		ch := l.input[l.pos]
		if ch == '\\' && l.pos+1 < len(l.input) {
			l.pos++
			switch l.input[l.pos] {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case '\\':
				sb.WriteByte('\\')
			case '"':
				sb.WriteByte('"')
			case '\'':
				sb.WriteByte('\'')
			default:
				sb.WriteByte('\\')
				sb.WriteByte(l.input[l.pos])
			}
			l.pos++
			continue
		}
		if ch == quote {
			l.pos++ // skip closing quote
			return Token{TokString, sb.String(), start}, nil
		}
		sb.WriteByte(ch)
		l.pos++
	}
	return Token{}, fmt.Errorf("unterminated string at position %d", start)
}

func (l *Lexer) readRegex() (Token, error) {
	start := l.pos
	l.pos++ // skip opening /

	var pattern strings.Builder
	for l.pos < len(l.input) {
		ch := l.input[l.pos]
		if ch == '\\' && l.pos+1 < len(l.input) {
			pattern.WriteByte(ch)
			l.pos++
			pattern.WriteByte(l.input[l.pos])
			l.pos++
			continue
		}
		if ch == '/' {
			l.pos++ // skip closing /
			// Read flags
			var flags strings.Builder
			for l.pos < len(l.input) && (l.input[l.pos] == 'i' || l.input[l.pos] == 'g' || l.input[l.pos] == 'm' || l.input[l.pos] == 's') {
				flags.WriteByte(l.input[l.pos])
				l.pos++
			}
			val := pattern.String()
			if strings.Contains(flags.String(), "i") {
				val = "(?i)" + val
			}
			return Token{TokRegex, val, start}, nil
		}
		pattern.WriteByte(ch)
		l.pos++
	}
	return Token{}, fmt.Errorf("unterminated regex at position %d", start)
}

func (l *Lexer) readIdent() Token {
	start := l.pos
	for l.pos < len(l.input) && isIdentPart(l.input[l.pos]) {
		l.pos++
	}
	val := l.input[start:l.pos]
	switch val {
	case "true":
		return Token{TokTrue, val, start}
	case "false":
		return Token{TokFalse, val, start}
	case "null":
		return Token{TokNull, val, start}
	}
	return Token{TokIdent, val, start}
}

func isIdentStart(ch byte) bool {
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_' || ch == '$'
}

func isIdentPart(ch byte) bool {
	return isIdentStart(ch) || (ch >= '0' && ch <= '9') || ch == '_'
}

// IsIdentRune is like isIdentPart but for runes.
func IsIdentRune(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '$'
}
