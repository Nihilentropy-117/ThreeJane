package expr

import (
	"fmt"
	"math"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type ValueType string

const (
	TypeNull   ValueType = "null"
	TypeString ValueType = "string"
	TypeNumber ValueType = "number"
	TypeBool   ValueType = "boolean"
	TypeDate   ValueType = "date"
	TypeList   ValueType = "list"
	TypeLink   ValueType = "link"
	TypeFile   ValueType = "file"
	TypeObject ValueType = "object"
	TypeRegexp ValueType = "regexp"
)

type Value struct {
	Type     ValueType
	Str      string
	Num      float64
	Bool     bool
	Date     time.Time
	List     []*Value
	Object   map[string]*Value
	Link     string // link target
	File     *FileValue
	Regexp   *regexp.Regexp
	IsNull   bool
}

type FileValue struct {
	Name       string
	Basename   string
	Path       string
	Folder     string
	Ext        string
	Size       int64
	Ctime      time.Time
	Mtime      time.Time
	Tags       []string
	Links      []string
	Properties map[string]any
}

var Null = &Value{Type: TypeNull, IsNull: true}

func StringVal(s string) *Value   { return &Value{Type: TypeString, Str: s} }
func NumberVal(n float64) *Value  { return &Value{Type: TypeNumber, Num: n} }
func BoolVal(b bool) *Value       { return &Value{Type: TypeBool, Bool: b} }
func DateVal(t time.Time) *Value  { return &Value{Type: TypeDate, Date: t} }
func LinkVal(target string) *Value { return &Value{Type: TypeLink, Link: target} }
func RegexpVal(r *regexp.Regexp) *Value { return &Value{Type: TypeRegexp, Regexp: r} }

func ListVal(items []*Value) *Value {
	return &Value{Type: TypeList, List: items}
}

func ObjectVal(m map[string]*Value) *Value {
	return &Value{Type: TypeObject, Object: m}
}

func FileVal(fv *FileValue) *Value {
	return &Value{Type: TypeFile, File: fv}
}

// ToGoValue converts a Value to a native Go value for output.
func (v *Value) ToGoValue() any {
	if v == nil || v.IsNull {
		return nil
	}
	switch v.Type {
	case TypeString:
		return v.Str
	case TypeNumber:
		if v.Num == math.Trunc(v.Num) {
			return int64(v.Num)
		}
		return v.Num
	case TypeBool:
		return v.Bool
	case TypeDate:
		return v.Date.Format(time.RFC3339)
	case TypeList:
		result := make([]any, len(v.List))
		for i, item := range v.List {
			result[i] = item.ToGoValue()
		}
		return result
	case TypeObject:
		result := make(map[string]any, len(v.Object))
		for k, val := range v.Object {
			result[k] = val.ToGoValue()
		}
		return result
	case TypeLink:
		return v.Link
	case TypeFile:
		return v.File.Path
	case TypeRegexp:
		return v.Regexp.String()
	default:
		return nil
	}
}

// IsTruthy returns whether the value is truthy.
func (v *Value) IsTruthy() bool {
	if v == nil || v.IsNull {
		return false
	}
	switch v.Type {
	case TypeBool:
		return v.Bool
	case TypeNumber:
		return v.Num != 0
	case TypeString:
		return v.Str != ""
	case TypeList:
		return len(v.List) > 0
	case TypeObject:
		return len(v.Object) > 0
	case TypeDate:
		return !v.Date.IsZero()
	default:
		return true
	}
}

func (v *Value) IsEmpty() bool {
	if v == nil || v.IsNull {
		return true
	}
	switch v.Type {
	case TypeString:
		return v.Str == ""
	case TypeList:
		return len(v.List) == 0
	case TypeObject:
		return len(v.Object) == 0
	case TypeNumber:
		return false
	case TypeBool:
		return false
	default:
		return false
	}
}

func (v *Value) ToString() string {
	if v == nil || v.IsNull {
		return ""
	}
	switch v.Type {
	case TypeString:
		return v.Str
	case TypeNumber:
		if v.Num == math.Trunc(v.Num) {
			return strconv.FormatInt(int64(v.Num), 10)
		}
		return strconv.FormatFloat(v.Num, 'f', -1, 64)
	case TypeBool:
		if v.Bool {
			return "true"
		}
		return "false"
	case TypeDate:
		return v.Date.Format("2006-01-02")
	case TypeList:
		parts := make([]string, len(v.List))
		for i, item := range v.List {
			parts[i] = item.ToString()
		}
		return "[" + strings.Join(parts, ", ") + "]"
	case TypeLink:
		return "[[" + v.Link + "]]"
	case TypeFile:
		return v.File.Path
	case TypeObject:
		return fmt.Sprintf("%v", v.Object)
	default:
		return ""
	}
}

func (v *Value) ToNumber() float64 {
	if v == nil || v.IsNull {
		return 0
	}
	switch v.Type {
	case TypeNumber:
		return v.Num
	case TypeString:
		n, err := strconv.ParseFloat(v.Str, 64)
		if err != nil {
			return 0
		}
		return n
	case TypeBool:
		if v.Bool {
			return 1
		}
		return 0
	default:
		return 0
	}
}

// Compare returns -1, 0, or 1.
func (v *Value) Compare(other *Value) int {
	if v.IsNull && other.IsNull {
		return 0
	}
	if v.IsNull {
		return -1
	}
	if other.IsNull {
		return 1
	}

	// Same type comparison
	switch v.Type {
	case TypeNumber:
		on := other.ToNumber()
		if v.Num < on {
			return -1
		}
		if v.Num > on {
			return 1
		}
		return 0
	case TypeString:
		return strings.Compare(v.Str, other.ToString())
	case TypeDate:
		if other.Type == TypeDate {
			if v.Date.Before(other.Date) {
				return -1
			}
			if v.Date.After(other.Date) {
				return 1
			}
			return 0
		}
	case TypeBool:
		a, b := 0, 0
		if v.Bool {
			a = 1
		}
		if other.Bool {
			b = 1
		}
		return a - b
	}

	// Fallback: string comparison
	return strings.Compare(v.ToString(), other.ToString())
}

// Equals checks value equality.
func (v *Value) Equals(other *Value) bool {
	if v.IsNull && other.IsNull {
		return true
	}
	if v.IsNull || other.IsNull {
		return false
	}
	if v.Type != other.Type {
		// Allow number/string cross-comparison
		if v.Type == TypeNumber || other.Type == TypeNumber {
			return v.ToNumber() == other.ToNumber()
		}
		return v.ToString() == other.ToString()
	}
	switch v.Type {
	case TypeString:
		return v.Str == other.Str
	case TypeNumber:
		return v.Num == other.Num
	case TypeBool:
		return v.Bool == other.Bool
	case TypeDate:
		return v.Date.Equal(other.Date)
	case TypeLink:
		return v.Link == other.Link
	default:
		return v.ToString() == other.ToString()
	}
}

// ListContains checks if a list value contains an item.
func (v *Value) ListContains(item *Value) bool {
	if v.Type != TypeList {
		// For strings, check substring
		if v.Type == TypeString {
			return strings.Contains(v.Str, item.ToString())
		}
		return false
	}
	for _, elem := range v.List {
		if elem.Equals(item) {
			return true
		}
	}
	return false
}

// CallMethod dispatches a method call on this value.
func (v *Value) CallMethod(name string, args []*Value) (*Value, error) {
	switch v.Type {
	case TypeString:
		return v.stringMethod(name, args)
	case TypeNumber:
		return v.numberMethod(name, args)
	case TypeDate:
		return v.dateMethod(name, args)
	case TypeList:
		return v.listMethod(name, args)
	case TypeLink:
		return v.linkMethod(name, args)
	case TypeFile:
		return v.fileMethod(name, args)
	case TypeObject:
		return v.objectMethod(name, args)
	case TypeRegexp:
		return v.regexpMethod(name, args)
	}

	// Universal methods
	switch name {
	case "isTruthy":
		return BoolVal(v.IsTruthy()), nil
	case "isType":
		if len(args) > 0 {
			return BoolVal(string(v.Type) == args[0].ToString()), nil
		}
		return BoolVal(false), nil
	case "toString":
		return StringVal(v.ToString()), nil
	case "isEmpty":
		return BoolVal(v.IsEmpty()), nil
	}

	return Null, fmt.Errorf("no method %s on type %s", name, v.Type)
}

// GetField gets a property/field of this value.
func (v *Value) GetField(name string) *Value {
	switch v.Type {
	case TypeString:
		if name == "length" {
			return NumberVal(float64(len(v.Str)))
		}
	case TypeList:
		if name == "length" {
			return NumberVal(float64(len(v.List)))
		}
	case TypeDate:
		return v.dateField(name)
	case TypeFile:
		return v.fileField(name)
	case TypeObject:
		if val, ok := v.Object[name]; ok {
			return val
		}
	}
	return Null
}

func (v *Value) stringMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "contains":
		if len(args) > 0 {
			return BoolVal(strings.Contains(v.Str, args[0].ToString())), nil
		}
	case "containsAll":
		for _, a := range args {
			if !strings.Contains(v.Str, a.ToString()) {
				return BoolVal(false), nil
			}
		}
		return BoolVal(true), nil
	case "containsAny":
		for _, a := range args {
			if strings.Contains(v.Str, a.ToString()) {
				return BoolVal(true), nil
			}
		}
		return BoolVal(false), nil
	case "startsWith":
		if len(args) > 0 {
			return BoolVal(strings.HasPrefix(v.Str, args[0].ToString())), nil
		}
	case "endsWith":
		if len(args) > 0 {
			return BoolVal(strings.HasSuffix(v.Str, args[0].ToString())), nil
		}
	case "isEmpty":
		return BoolVal(v.Str == ""), nil
	case "lower":
		return StringVal(strings.ToLower(v.Str)), nil
	case "title":
		return StringVal(strings.Title(v.Str)), nil
	case "trim":
		return StringVal(strings.TrimSpace(v.Str)), nil
	case "replace":
		if len(args) >= 2 {
			return StringVal(strings.ReplaceAll(v.Str, args[0].ToString(), args[1].ToString())), nil
		}
	case "repeat":
		if len(args) > 0 {
			n := int(args[0].ToNumber())
			if n < 0 {
				n = 0
			}
			return StringVal(strings.Repeat(v.Str, n)), nil
		}
	case "reverse":
		runes := []rune(v.Str)
		for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
			runes[i], runes[j] = runes[j], runes[i]
		}
		return StringVal(string(runes)), nil
	case "slice":
		if len(args) >= 1 {
			start := int(args[0].ToNumber())
			end := len(v.Str)
			if len(args) >= 2 {
				end = int(args[1].ToNumber())
			}
			if start < 0 {
				start = len(v.Str) + start
			}
			if end < 0 {
				end = len(v.Str) + end
			}
			if start < 0 {
				start = 0
			}
			if end > len(v.Str) {
				end = len(v.Str)
			}
			if start >= end {
				return StringVal(""), nil
			}
			return StringVal(v.Str[start:end]), nil
		}
	case "split":
		sep := " "
		if len(args) > 0 {
			sep = args[0].ToString()
		}
		parts := strings.Split(v.Str, sep)
		items := make([]*Value, len(parts))
		for i, p := range parts {
			items[i] = StringVal(p)
		}
		return ListVal(items), nil
	case "isTruthy":
		return BoolVal(v.Str != ""), nil
	case "isType":
		if len(args) > 0 {
			return BoolVal(args[0].ToString() == "string"), nil
		}
	case "toString":
		return v, nil
	}
	return Null, fmt.Errorf("unknown string method: %s", name)
}

func (v *Value) numberMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "abs":
		return NumberVal(math.Abs(v.Num)), nil
	case "ceil":
		return NumberVal(math.Ceil(v.Num)), nil
	case "floor":
		return NumberVal(math.Floor(v.Num)), nil
	case "round":
		if len(args) > 0 {
			digits := int(args[0].ToNumber())
			p := math.Pow(10, float64(digits))
			return NumberVal(math.Round(v.Num*p) / p), nil
		}
		return NumberVal(math.Round(v.Num)), nil
	case "toFixed":
		precision := 0
		if len(args) > 0 {
			precision = int(args[0].ToNumber())
		}
		s := strconv.FormatFloat(v.Num, 'f', precision, 64)
		return StringVal(s), nil
	case "isEmpty":
		return BoolVal(false), nil
	case "isTruthy":
		return BoolVal(v.Num != 0), nil
	case "isType":
		if len(args) > 0 {
			return BoolVal(args[0].ToString() == "number"), nil
		}
	case "toString":
		return StringVal(v.ToString()), nil
	}
	return Null, fmt.Errorf("unknown number method: %s", name)
}

func (v *Value) dateField(name string) *Value {
	switch name {
	case "year":
		return NumberVal(float64(v.Date.Year()))
	case "month":
		return NumberVal(float64(v.Date.Month()))
	case "day":
		return NumberVal(float64(v.Date.Day()))
	case "hour":
		return NumberVal(float64(v.Date.Hour()))
	case "minute":
		return NumberVal(float64(v.Date.Minute()))
	case "second":
		return NumberVal(float64(v.Date.Second()))
	case "millisecond":
		return NumberVal(float64(v.Date.Nanosecond() / 1e6))
	}
	return Null
}

func (v *Value) dateMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "date":
		d := time.Date(v.Date.Year(), v.Date.Month(), v.Date.Day(), 0, 0, 0, 0, v.Date.Location())
		return DateVal(d), nil
	case "time":
		return StringVal(v.Date.Format("15:04:05")), nil
	case "format":
		if len(args) > 0 {
			return StringVal(formatDate(v.Date, args[0].ToString())), nil
		}
		return StringVal(v.Date.Format("2006-01-02")), nil
	case "relative":
		return StringVal(relativeTime(v.Date)), nil
	case "isEmpty":
		return BoolVal(v.Date.IsZero()), nil
	case "isTruthy":
		return BoolVal(!v.Date.IsZero()), nil
	case "toString":
		return StringVal(v.Date.Format(time.RFC3339)), nil
	}
	return Null, fmt.Errorf("unknown date method: %s", name)
}

func (v *Value) listMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "contains":
		if len(args) > 0 {
			return BoolVal(v.ListContains(args[0])), nil
		}
	case "containsAll":
		for _, a := range args {
			if !v.ListContains(a) {
				return BoolVal(false), nil
			}
		}
		return BoolVal(true), nil
	case "containsAny":
		for _, a := range args {
			if v.ListContains(a) {
				return BoolVal(true), nil
			}
		}
		return BoolVal(false), nil
	case "flat":
		var items []*Value
		for _, item := range v.List {
			if item.Type == TypeList {
				items = append(items, item.List...)
			} else {
				items = append(items, item)
			}
		}
		return ListVal(items), nil
	case "isEmpty":
		return BoolVal(len(v.List) == 0), nil
	case "join":
		sep := ", "
		if len(args) > 0 {
			sep = args[0].ToString()
		}
		parts := make([]string, len(v.List))
		for i, item := range v.List {
			parts[i] = item.ToString()
		}
		return StringVal(strings.Join(parts, sep)), nil
	case "reverse":
		items := make([]*Value, len(v.List))
		for i, item := range v.List {
			items[len(v.List)-1-i] = item
		}
		return ListVal(items), nil
	case "slice":
		start := 0
		end := len(v.List)
		if len(args) >= 1 {
			start = int(args[0].ToNumber())
		}
		if len(args) >= 2 {
			end = int(args[1].ToNumber())
		}
		if start < 0 {
			start = len(v.List) + start
		}
		if end < 0 {
			end = len(v.List) + end
		}
		if start < 0 {
			start = 0
		}
		if end > len(v.List) {
			end = len(v.List)
		}
		if start >= end {
			return ListVal(nil), nil
		}
		return ListVal(v.List[start:end]), nil
	case "sort":
		items := make([]*Value, len(v.List))
		copy(items, v.List)
		sort.Slice(items, func(i, j int) bool {
			return items[i].Compare(items[j]) < 0
		})
		return ListVal(items), nil
	case "unique":
		seen := make(map[string]bool)
		var items []*Value
		for _, item := range v.List {
			key := item.ToString()
			if !seen[key] {
				seen[key] = true
				items = append(items, item)
			}
		}
		return ListVal(items), nil
	case "filter", "map", "reduce":
		// These require lambda evaluation - handled in the evaluator
		return Null, fmt.Errorf("list.%s requires evaluator context", name)
	case "isTruthy":
		return BoolVal(len(v.List) > 0), nil
	case "toString":
		return StringVal(v.ToString()), nil
	}
	return Null, fmt.Errorf("unknown list method: %s", name)
}

func (v *Value) linkMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "asFile":
		// Returns a file value - needs vault context, stub here
		return Null, nil
	case "linksTo":
		if len(args) > 0 {
			return BoolVal(strings.EqualFold(v.Link, args[0].ToString())), nil
		}
	case "isTruthy":
		return BoolVal(v.Link != ""), nil
	case "toString":
		return StringVal(v.Link), nil
	}
	return Null, fmt.Errorf("unknown link method: %s", name)
}

func (v *Value) fileMethod(name string, args []*Value) (*Value, error) {
	if v.File == nil {
		return Null, nil
	}
	switch name {
	case "asLink":
		return LinkVal(v.File.Basename), nil
	case "hasLink":
		if len(args) > 0 {
			target := args[0].ToString()
			for _, l := range v.File.Links {
				if strings.EqualFold(l, target) {
					return BoolVal(true), nil
				}
			}
			return BoolVal(false), nil
		}
	case "hasProperty":
		if len(args) > 0 {
			prop := args[0].ToString()
			_, ok := v.File.Properties[prop]
			return BoolVal(ok), nil
		}
	case "hasTag":
		for _, arg := range args {
			tag := arg.ToString()
			found := false
			for _, t := range v.File.Tags {
				if strings.EqualFold(t, tag) {
					found = true
					break
				}
			}
			if !found {
				return BoolVal(false), nil
			}
		}
		return BoolVal(true), nil
	case "inFolder":
		if len(args) > 0 {
			folder := args[0].ToString()
			return BoolVal(v.File.Folder == folder || strings.HasPrefix(v.File.Folder, folder+"/")), nil
		}
	case "isTruthy":
		return BoolVal(true), nil
	case "toString":
		return StringVal(v.File.Path), nil
	}
	return Null, fmt.Errorf("unknown file method: %s", name)
}

func (v *Value) fileField(name string) *Value {
	if v.File == nil {
		return Null
	}
	switch name {
	case "name":
		return StringVal(v.File.Basename)
	case "basename":
		return StringVal(v.File.Basename)
	case "path":
		return StringVal(v.File.Path)
	case "folder":
		return StringVal(v.File.Folder)
	case "ext":
		return StringVal(v.File.Ext)
	case "size":
		return NumberVal(float64(v.File.Size))
	case "ctime":
		return DateVal(v.File.Ctime)
	case "mtime":
		return DateVal(v.File.Mtime)
	case "tags":
		items := make([]*Value, len(v.File.Tags))
		for i, t := range v.File.Tags {
			items[i] = StringVal(t)
		}
		return ListVal(items)
	case "links":
		items := make([]*Value, len(v.File.Links))
		for i, l := range v.File.Links {
			items[i] = LinkVal(l)
		}
		return ListVal(items)
	case "properties":
		obj := make(map[string]*Value, len(v.File.Properties))
		for k, val := range v.File.Properties {
			obj[k] = GoToValue(val)
		}
		return ObjectVal(obj)
	}
	return Null
}

func (v *Value) objectMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "isEmpty":
		return BoolVal(len(v.Object) == 0), nil
	case "keys":
		keys := make([]*Value, 0, len(v.Object))
		for k := range v.Object {
			keys = append(keys, StringVal(k))
		}
		return ListVal(keys), nil
	case "values":
		vals := make([]*Value, 0, len(v.Object))
		for _, val := range v.Object {
			vals = append(vals, val)
		}
		return ListVal(vals), nil
	case "isTruthy":
		return BoolVal(len(v.Object) > 0), nil
	case "toString":
		return StringVal(v.ToString()), nil
	}
	return Null, fmt.Errorf("unknown object method: %s", name)
}

func (v *Value) regexpMethod(name string, args []*Value) (*Value, error) {
	switch name {
	case "matches":
		if len(args) > 0 && v.Regexp != nil {
			return BoolVal(v.Regexp.MatchString(args[0].ToString())), nil
		}
	}
	return Null, fmt.Errorf("unknown regexp method: %s", name)
}

// GoToValue converts a Go value to an expr.Value.
func GoToValue(v any) *Value {
	if v == nil {
		return Null
	}
	switch val := v.(type) {
	case string:
		// Try to parse as date
		if t, err := parseDate(val); err == nil {
			return DateVal(t)
		}
		return StringVal(val)
	case float64:
		return NumberVal(val)
	case float32:
		return NumberVal(float64(val))
	case int:
		return NumberVal(float64(val))
	case int64:
		return NumberVal(float64(val))
	case int32:
		return NumberVal(float64(val))
	case bool:
		return BoolVal(val)
	case []any:
		items := make([]*Value, len(val))
		for i, item := range val {
			items[i] = GoToValue(item)
		}
		return ListVal(items)
	case []string:
		items := make([]*Value, len(val))
		for i, s := range val {
			items[i] = StringVal(s)
		}
		return ListVal(items)
	case map[string]any:
		obj := make(map[string]*Value, len(val))
		for k, v := range val {
			obj[k] = GoToValue(v)
		}
		return ObjectVal(obj)
	case time.Time:
		return DateVal(val)
	case *Value:
		return val
	default:
		return StringVal(fmt.Sprintf("%v", val))
	}
}

func parseDate(s string) (time.Time, error) {
	formats := []string{
		"2006-01-02T15:04:05Z07:00",
		"2006-01-02T15:04:05",
		"2006-01-02 15:04:05",
		"2006-01-02",
	}
	for _, f := range formats {
		if t, err := time.Parse(f, s); err == nil {
			return t, nil
		}
	}
	return time.Time{}, fmt.Errorf("not a date: %s", s)
}

func formatDate(t time.Time, format string) string {
	// Convert common date format tokens to Go layout
	r := strings.NewReplacer(
		"YYYY", "2006",
		"yyyy", "2006",
		"YY", "06",
		"yy", "06",
		"MM", "01",
		"DD", "02",
		"dd", "02",
		"HH", "15",
		"hh", "03",
		"mm", "04",
		"ss", "05",
		"SSS", "000",
	)
	return t.Format(r.Replace(format))
}

func relativeTime(t time.Time) string {
	diff := time.Since(t)
	if diff < 0 {
		diff = -diff
		if diff < time.Minute {
			return "in a few seconds"
		}
		if diff < time.Hour {
			return fmt.Sprintf("in %d minutes", int(diff.Minutes()))
		}
		if diff < 24*time.Hour {
			return fmt.Sprintf("in %d hours", int(diff.Hours()))
		}
		return fmt.Sprintf("in %d days", int(diff.Hours()/24))
	}
	if diff < time.Minute {
		return "a few seconds ago"
	}
	if diff < time.Hour {
		return fmt.Sprintf("%d minutes ago", int(diff.Minutes()))
	}
	if diff < 24*time.Hour {
		return fmt.Sprintf("%d hours ago", int(diff.Hours()))
	}
	return fmt.Sprintf("%d days ago", int(diff.Hours()/24))
}
