package expr

import (
	"fmt"
	"regexp"
	"strconv"
)

// Parser is a recursive-descent parser for the Bases expression language.
type Parser struct {
	tokens []Token
	pos    int
}

func NewParser(tokens []Token) *Parser {
	return &Parser{tokens: tokens}
}

// Parse parses the full expression.
func (p *Parser) Parse() (Node, error) {
	node, err := p.parseTernary()
	if err != nil {
		return nil, err
	}
	if p.current().Type != TokEOF {
		return nil, fmt.Errorf("unexpected token %s at position %d", p.current(), p.current().Pos)
	}
	return node, nil
}

func (p *Parser) current() Token {
	if p.pos < len(p.tokens) {
		return p.tokens[p.pos]
	}
	return Token{Type: TokEOF}
}

func (p *Parser) advance() Token {
	tok := p.current()
	if p.pos < len(p.tokens) {
		p.pos++
	}
	return tok
}

func (p *Parser) expect(typ TokenType) (Token, error) {
	tok := p.current()
	if tok.Type != typ {
		return tok, fmt.Errorf("expected %s but got %s at position %d", tokenNames[typ], tok, tok.Pos)
	}
	p.advance()
	return tok, nil
}

// parseTernary: expr ? expr : expr
func (p *Parser) parseTernary() (Node, error) {
	node, err := p.parseOr()
	if err != nil {
		return nil, err
	}
	if p.current().Type == TokQuestion {
		p.advance()
		then, err := p.parseTernary()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(TokColon); err != nil {
			return nil, err
		}
		els, err := p.parseTernary()
		if err != nil {
			return nil, err
		}
		return &TernaryExpr{Condition: node, Then: then, Else: els}, nil
	}
	return node, nil
}

// parseOr: expr || expr
func (p *Parser) parseOr() (Node, error) {
	left, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokOr {
		p.advance()
		right, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: "||", Left: left, Right: right}
	}
	return left, nil
}

// parseAnd: expr && expr
func (p *Parser) parseAnd() (Node, error) {
	left, err := p.parseEquality()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokAnd {
		p.advance()
		right, err := p.parseEquality()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: "&&", Left: left, Right: right}
	}
	return left, nil
}

// parseEquality: expr == expr | expr != expr
func (p *Parser) parseEquality() (Node, error) {
	left, err := p.parseComparison()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokEq || p.current().Type == TokNeq {
		op := p.advance().Val
		right, err := p.parseComparison()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: op, Left: left, Right: right}
	}
	return left, nil
}

// parseComparison: expr < expr | expr <= expr | expr > expr | expr >= expr
func (p *Parser) parseComparison() (Node, error) {
	left, err := p.parseAddSub()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokLt || p.current().Type == TokLte ||
		p.current().Type == TokGt || p.current().Type == TokGte {
		op := p.advance().Val
		right, err := p.parseAddSub()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: op, Left: left, Right: right}
	}
	return left, nil
}

// parseAddSub: expr + expr | expr - expr
func (p *Parser) parseAddSub() (Node, error) {
	left, err := p.parseMulDiv()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokPlus || p.current().Type == TokMinus {
		op := p.advance().Val
		right, err := p.parseMulDiv()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: op, Left: left, Right: right}
	}
	return left, nil
}

// parseMulDiv: expr * expr | expr / expr | expr % expr
func (p *Parser) parseMulDiv() (Node, error) {
	left, err := p.parseUnary()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokStar || p.current().Type == TokSlash || p.current().Type == TokPercent {
		op := p.advance().Val
		right, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: op, Left: left, Right: right}
	}
	return left, nil
}

// parseUnary: !expr | -expr
func (p *Parser) parseUnary() (Node, error) {
	if p.current().Type == TokNot {
		p.advance()
		operand, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		return &UnaryExpr{Op: "!", Operand: operand}, nil
	}
	if p.current().Type == TokMinus {
		p.advance()
		operand, err := p.parseUnary()
		if err != nil {
			return nil, err
		}
		return &UnaryExpr{Op: "-", Operand: operand}, nil
	}
	return p.parsePostfix()
}

// parsePostfix: primary (.prop | [index] | (args))*
func (p *Parser) parsePostfix() (Node, error) {
	node, err := p.parsePrimary()
	if err != nil {
		return nil, err
	}

	for {
		switch p.current().Type {
		case TokDot:
			p.advance()
			prop, err := p.expect(TokIdent)
			if err != nil {
				return nil, err
			}
			// Check if it's a method call
			if p.current().Type == TokLParen {
				p.advance()
				args, err := p.parseArgList()
				if err != nil {
					return nil, err
				}
				if _, err := p.expect(TokRParen); err != nil {
					return nil, err
				}
				node = &MethodExpr{Object: node, Method: prop.Val, Args: args}
			} else {
				node = &MemberExpr{Object: node, Property: prop.Val}
			}
		case TokLBracket:
			p.advance()
			index, err := p.parseTernary()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(TokRBracket); err != nil {
				return nil, err
			}
			node = &IndexExpr{Object: node, Index: index}
		case TokLParen:
			// Function call on an identifier
			p.advance()
			args, err := p.parseArgList()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(TokRParen); err != nil {
				return nil, err
			}
			node = &CallExpr{Function: node, Args: args}
		default:
			return node, nil
		}
	}
}

func (p *Parser) parseArgList() ([]Node, error) {
	var args []Node
	if p.current().Type == TokRParen {
		return args, nil
	}
	for {
		arg, err := p.parseTernary()
		if err != nil {
			return nil, err
		}
		args = append(args, arg)
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}
	return args, nil
}

// parsePrimary: number | string | bool | null | regex | ident | list | object | (expr)
func (p *Parser) parsePrimary() (Node, error) {
	tok := p.current()

	switch tok.Type {
	case TokNumber:
		p.advance()
		n, err := strconv.ParseFloat(tok.Val, 64)
		if err != nil {
			return nil, fmt.Errorf("invalid number %s", tok.Val)
		}
		return &NumberLit{Value: n}, nil

	case TokString:
		p.advance()
		return &StringLit{Value: tok.Val}, nil

	case TokTrue:
		p.advance()
		return &BoolLit{Value: true}, nil

	case TokFalse:
		p.advance()
		return &BoolLit{Value: false}, nil

	case TokNull:
		p.advance()
		return &NullLit{}, nil

	case TokRegex:
		p.advance()
		_, err := regexp.Compile(tok.Val)
		if err != nil {
			return nil, fmt.Errorf("invalid regex: %s", err)
		}
		return &RegexLit{Pattern: tok.Val}, nil

	case TokIdent:
		p.advance()
		return &Ident{Name: tok.Val}, nil

	case TokLParen:
		p.advance()
		node, err := p.parseTernary()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(TokRParen); err != nil {
			return nil, err
		}
		return node, nil

	case TokLBracket:
		return p.parseListLiteral()

	case TokLBrace:
		return p.parseObjectLiteral()

	default:
		return nil, fmt.Errorf("unexpected token %s at position %d", tok, tok.Pos)
	}
}

func (p *Parser) parseListLiteral() (Node, error) {
	p.advance() // skip [
	var items []Node
	if p.current().Type == TokRBracket {
		p.advance()
		return &ListExpr{Items: items}, nil
	}
	for {
		item, err := p.parseTernary()
		if err != nil {
			return nil, err
		}
		items = append(items, item)
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}
	if _, err := p.expect(TokRBracket); err != nil {
		return nil, err
	}
	return &ListExpr{Items: items}, nil
}

func (p *Parser) parseObjectLiteral() (Node, error) {
	p.advance() // skip {
	var keys []string
	var values []Node

	if p.current().Type == TokRBrace {
		p.advance()
		return &ObjectExpr{Keys: keys, Values: values}, nil
	}

	for {
		// Key: string or identifier
		var key string
		if p.current().Type == TokString {
			key = p.advance().Val
		} else if p.current().Type == TokIdent {
			key = p.advance().Val
		} else {
			return nil, fmt.Errorf("expected object key at position %d", p.current().Pos)
		}

		if _, err := p.expect(TokColon); err != nil {
			return nil, err
		}

		value, err := p.parseTernary()
		if err != nil {
			return nil, err
		}

		keys = append(keys, key)
		values = append(values, value)

		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}

	if _, err := p.expect(TokRBrace); err != nil {
		return nil, err
	}
	return &ObjectExpr{Keys: keys, Values: values}, nil
}

// ParseExpression is a convenience function to parse an expression string.
func ParseExpression(input string) (Node, error) {
	lexer := NewLexer(input)
	tokens, err := lexer.Tokenize()
	if err != nil {
		return nil, err
	}
	parser := NewParser(tokens)
	return parser.Parse()
}
