package expr

import (
	"fmt"
	"math"
	"math/rand"
	"regexp"
	"strings"
	"time"
)

// Context provides variable resolution for expression evaluation.
type Context struct {
	Variables map[string]*Value
	Parent    *Context
}

func NewContext() *Context {
	return &Context{Variables: make(map[string]*Value)}
}

func (c *Context) Get(name string) *Value {
	if v, ok := c.Variables[name]; ok {
		return v
	}
	if c.Parent != nil {
		return c.Parent.Get(name)
	}
	return Null
}

func (c *Context) Set(name string, val *Value) {
	c.Variables[name] = val
}

func (c *Context) Child() *Context {
	return &Context{Variables: make(map[string]*Value), Parent: c}
}

// Eval evaluates an AST node in the given context.
func Eval(node Node, ctx *Context) (*Value, error) {
	if node == nil {
		return Null, nil
	}
	switch n := node.(type) {
	case *NumberLit:
		return NumberVal(n.Value), nil
	case *StringLit:
		return StringVal(n.Value), nil
	case *BoolLit:
		return BoolVal(n.Value), nil
	case *NullLit:
		return Null, nil
	case *RegexLit:
		r, err := regexp.Compile(n.Pattern)
		if err != nil {
			return Null, err
		}
		return RegexpVal(r), nil

	case *Ident:
		return ctx.Get(n.Name), nil

	case *BinaryExpr:
		return evalBinary(n, ctx)

	case *UnaryExpr:
		return evalUnary(n, ctx)

	case *MemberExpr:
		obj, err := Eval(n.Object, ctx)
		if err != nil {
			return Null, err
		}
		return obj.GetField(n.Property), nil

	case *IndexExpr:
		obj, err := Eval(n.Object, ctx)
		if err != nil {
			return Null, err
		}
		idx, err := Eval(n.Index, ctx)
		if err != nil {
			return Null, err
		}
		return evalIndex(obj, idx), nil

	case *CallExpr:
		return evalCall(n, ctx)

	case *MethodExpr:
		return evalMethod(n, ctx)

	case *ListExpr:
		items := make([]*Value, len(n.Items))
		for i, item := range n.Items {
			v, err := Eval(item, ctx)
			if err != nil {
				return Null, err
			}
			items[i] = v
		}
		return ListVal(items), nil

	case *ObjectExpr:
		obj := make(map[string]*Value, len(n.Keys))
		for i, key := range n.Keys {
			v, err := Eval(n.Values[i], ctx)
			if err != nil {
				return Null, err
			}
			obj[key] = v
		}
		return ObjectVal(obj), nil

	case *TernaryExpr:
		cond, err := Eval(n.Condition, ctx)
		if err != nil {
			return Null, err
		}
		if cond.IsTruthy() {
			return Eval(n.Then, ctx)
		}
		return Eval(n.Else, ctx)

	default:
		return Null, fmt.Errorf("unknown node type: %T", node)
	}
}

func evalBinary(n *BinaryExpr, ctx *Context) (*Value, error) {
	left, err := Eval(n.Left, ctx)
	if err != nil {
		return Null, err
	}
	right, err := Eval(n.Right, ctx)
	if err != nil {
		return Null, err
	}

	switch n.Op {
	case "+":
		return evalAdd(left, right), nil
	case "-":
		return evalSub(left, right), nil
	case "*":
		return NumberVal(left.ToNumber() * right.ToNumber()), nil
	case "/":
		d := right.ToNumber()
		if d == 0 {
			return Null, nil
		}
		return NumberVal(left.ToNumber() / d), nil
	case "%":
		d := right.ToNumber()
		if d == 0 {
			return Null, nil
		}
		return NumberVal(math.Mod(left.ToNumber(), d)), nil
	case "==":
		return BoolVal(left.Equals(right)), nil
	case "!=":
		return BoolVal(!left.Equals(right)), nil
	case "<":
		return BoolVal(left.Compare(right) < 0), nil
	case "<=":
		return BoolVal(left.Compare(right) <= 0), nil
	case ">":
		return BoolVal(left.Compare(right) > 0), nil
	case ">=":
		return BoolVal(left.Compare(right) >= 0), nil
	case "&&":
		return BoolVal(left.IsTruthy() && right.IsTruthy()), nil
	case "||":
		if left.IsTruthy() {
			return left, nil
		}
		return right, nil
	}
	return Null, fmt.Errorf("unknown operator: %s", n.Op)
}

func evalAdd(left, right *Value) *Value {
	// Date + duration string
	if left.Type == TypeDate && right.Type == TypeString {
		d := parseDuration(right.Str)
		return DateVal(left.Date.Add(d))
	}
	// String concatenation
	if left.Type == TypeString || right.Type == TypeString {
		return StringVal(left.ToString() + right.ToString())
	}
	// List concatenation
	if left.Type == TypeList && right.Type == TypeList {
		items := make([]*Value, 0, len(left.List)+len(right.List))
		items = append(items, left.List...)
		items = append(items, right.List...)
		return ListVal(items)
	}
	return NumberVal(left.ToNumber() + right.ToNumber())
}

func evalSub(left, right *Value) *Value {
	// Date - duration string
	if left.Type == TypeDate && right.Type == TypeString {
		d := parseDuration(right.Str)
		return DateVal(left.Date.Add(-d))
	}
	// Date - Date = milliseconds diff
	if left.Type == TypeDate && right.Type == TypeDate {
		diff := left.Date.Sub(right.Date)
		return NumberVal(float64(diff.Milliseconds()))
	}
	return NumberVal(left.ToNumber() - right.ToNumber())
}

func evalUnary(n *UnaryExpr, ctx *Context) (*Value, error) {
	operand, err := Eval(n.Operand, ctx)
	if err != nil {
		return Null, err
	}
	switch n.Op {
	case "!":
		return BoolVal(!operand.IsTruthy()), nil
	case "-":
		return NumberVal(-operand.ToNumber()), nil
	}
	return Null, fmt.Errorf("unknown unary operator: %s", n.Op)
}

func evalIndex(obj, idx *Value) *Value {
	switch obj.Type {
	case TypeList:
		i := int(idx.ToNumber())
		if i < 0 {
			i = len(obj.List) + i
		}
		if i >= 0 && i < len(obj.List) {
			return obj.List[i]
		}
	case TypeObject:
		key := idx.ToString()
		if v, ok := obj.Object[key]; ok {
			return v
		}
	case TypeString:
		i := int(idx.ToNumber())
		if i >= 0 && i < len(obj.Str) {
			return StringVal(string(obj.Str[i]))
		}
	}
	return Null
}

func evalCall(n *CallExpr, ctx *Context) (*Value, error) {
	// Resolve function name
	ident, ok := n.Function.(*Ident)
	if !ok {
		// Could be a computed function
		fn, err := Eval(n.Function, ctx)
		if err != nil {
			return Null, err
		}
		_ = fn
		return Null, fmt.Errorf("cannot call non-function value")
	}

	args := make([]*Value, len(n.Args))
	for i, arg := range n.Args {
		v, err := Eval(arg, ctx)
		if err != nil {
			return Null, err
		}
		args[i] = v
	}

	return callGlobalFunction(ident.Name, args, ctx)
}

func evalMethod(n *MethodExpr, ctx *Context) (*Value, error) {
	obj, err := Eval(n.Object, ctx)
	if err != nil {
		return Null, err
	}

	// Special handling for list.filter/map/reduce which need lazy arg evaluation
	if obj.Type == TypeList && (n.Method == "filter" || n.Method == "map" || n.Method == "reduce") {
		return evalListHigherOrder(obj, n.Method, n.Args, ctx)
	}

	args := make([]*Value, len(n.Args))
	for i, arg := range n.Args {
		v, err := Eval(arg, ctx)
		if err != nil {
			return Null, err
		}
		args[i] = v
	}

	return obj.CallMethod(n.Method, args)
}

func evalListHigherOrder(list *Value, method string, argNodes []Node, ctx *Context) (*Value, error) {
	if len(argNodes) == 0 {
		return Null, fmt.Errorf("list.%s requires at least one argument", method)
	}

	switch method {
	case "filter":
		var result []*Value
		for _, item := range list.List {
			child := ctx.Child()
			child.Set("_", item)
			child.Set("current", item)
			v, err := Eval(argNodes[0], child)
			if err != nil {
				return Null, err
			}
			if v.IsTruthy() {
				result = append(result, item)
			}
		}
		return ListVal(result), nil

	case "map":
		result := make([]*Value, len(list.List))
		for i, item := range list.List {
			child := ctx.Child()
			child.Set("_", item)
			child.Set("current", item)
			v, err := Eval(argNodes[0], child)
			if err != nil {
				return Null, err
			}
			result[i] = v
		}
		return ListVal(result), nil

	case "reduce":
		if len(list.List) == 0 {
			if len(argNodes) >= 2 {
				return Eval(argNodes[1], ctx)
			}
			return Null, nil
		}
		var acc *Value
		startIdx := 0
		if len(argNodes) >= 2 {
			var err error
			acc, err = Eval(argNodes[1], ctx)
			if err != nil {
				return Null, err
			}
		} else {
			acc = list.List[0]
			startIdx = 1
		}
		for i := startIdx; i < len(list.List); i++ {
			child := ctx.Child()
			child.Set("acc", acc)
			child.Set("current", list.List[i])
			child.Set("_", list.List[i])
			var err error
			acc, err = Eval(argNodes[0], child)
			if err != nil {
				return Null, err
			}
		}
		return acc, nil
	}
	return Null, nil
}

func callGlobalFunction(name string, args []*Value, ctx *Context) (*Value, error) {
	switch name {
	case "if":
		if len(args) >= 3 {
			if args[0].IsTruthy() {
				return args[1], nil
			}
			return args[2], nil
		}
		if len(args) >= 2 {
			if args[0].IsTruthy() {
				return args[1], nil
			}
			return Null, nil
		}
	case "date":
		if len(args) > 0 {
			s := args[0].ToString()
			t, err := parseDate(s)
			if err != nil {
				return Null, nil
			}
			return DateVal(t), nil
		}
	case "now":
		return DateVal(time.Now()), nil
	case "today":
		now := time.Now()
		return DateVal(time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())), nil
	case "duration":
		if len(args) > 0 {
			d := parseDuration(args[0].ToString())
			return NumberVal(float64(d.Milliseconds())), nil
		}
	case "number":
		if len(args) > 0 {
			return NumberVal(args[0].ToNumber()), nil
		}
	case "min":
		if len(args) == 0 {
			return Null, nil
		}
		result := args[0]
		for _, a := range args[1:] {
			if a.Compare(result) < 0 {
				result = a
			}
		}
		return result, nil
	case "max":
		if len(args) == 0 {
			return Null, nil
		}
		result := args[0]
		for _, a := range args[1:] {
			if a.Compare(result) > 0 {
				result = a
			}
		}
		return result, nil
	case "random":
		return NumberVal(rand.Float64()), nil
	case "link":
		if len(args) > 0 {
			return LinkVal(args[0].ToString()), nil
		}
	case "file":
		// Returns a file reference - needs vault context
		if len(args) > 0 {
			return StringVal(args[0].ToString()), nil
		}
	case "list":
		return ListVal(args), nil
	case "image":
		if len(args) > 0 {
			return StringVal(fmt.Sprintf("![image](%s)", args[0].ToString())), nil
		}
	case "icon":
		if len(args) > 0 {
			return StringVal(args[0].ToString()), nil
		}
	case "html":
		if len(args) > 0 {
			return StringVal(args[0].ToString()), nil
		}
	case "escapeHTML":
		if len(args) > 0 {
			s := args[0].ToString()
			s = strings.ReplaceAll(s, "&", "&amp;")
			s = strings.ReplaceAll(s, "<", "&lt;")
			s = strings.ReplaceAll(s, ">", "&gt;")
			s = strings.ReplaceAll(s, "\"", "&quot;")
			s = strings.ReplaceAll(s, "'", "&#39;")
			return StringVal(s), nil
		}
	}
	return Null, fmt.Errorf("unknown function: %s", name)
}

// parseDuration parses a duration string like "1d", "2w", "3h".
func parseDuration(s string) time.Duration {
	s = strings.TrimSpace(s)
	if len(s) == 0 {
		return 0
	}

	// Try standard Go duration first
	if d, err := time.ParseDuration(s); err == nil {
		return d
	}

	// Parse custom format: number + unit
	i := 0
	for i < len(s) && ((s[i] >= '0' && s[i] <= '9') || s[i] == '.') {
		i++
	}
	if i == 0 {
		return 0
	}

	numStr := s[:i]
	unit := strings.TrimSpace(s[i:])

	var num float64
	fmt.Sscanf(numStr, "%f", &num)

	switch unit {
	case "s", "second", "seconds":
		return time.Duration(num * float64(time.Second))
	case "m", "minute", "minutes":
		return time.Duration(num * float64(time.Minute))
	case "h", "hour", "hours":
		return time.Duration(num * float64(time.Hour))
	case "d", "day", "days":
		return time.Duration(num * 24 * float64(time.Hour))
	case "w", "week", "weeks":
		return time.Duration(num * 7 * 24 * float64(time.Hour))
	case "M", "month", "months":
		return time.Duration(num * 30 * 24 * float64(time.Hour))
	case "y", "year", "years":
		return time.Duration(num * 365 * 24 * float64(time.Hour))
	}
	return 0
}

// EvalExpression is a convenience function to parse and evaluate an expression string.
func EvalExpression(input string, ctx *Context) (*Value, error) {
	node, err := ParseExpression(input)
	if err != nil {
		return nil, err
	}
	return Eval(node, ctx)
}
