package output

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"sort"
	"strings"

	"gopkg.in/yaml.v3"
)

type Format string

const (
	JSON  Format = "json"
	Table Format = "table"
	CSV   Format = "csv"
	YAML  Format = "yaml"
)

func ParseFormat(s string) (Format, error) {
	switch strings.ToLower(s) {
	case "json", "":
		return JSON, nil
	case "table":
		return Table, nil
	case "csv":
		return CSV, nil
	case "yaml":
		return YAML, nil
	default:
		return "", fmt.Errorf("unknown format: %s", s)
	}
}

func Write(w io.Writer, format Format, data any) error {
	switch format {
	case JSON:
		return writeJSON(w, data)
	case Table:
		return writeTable(w, data)
	case CSV:
		return writeCSV(w, data)
	case YAML:
		return writeYAML(w, data)
	default:
		return writeJSON(w, data)
	}
}

func writeJSON(w io.Writer, data any) error {
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(data)
}

func writeYAML(w io.Writer, data any) error {
	enc := yaml.NewEncoder(w)
	enc.SetIndent(2)
	defer enc.Close()
	return enc.Encode(data)
}

func writeTable(w io.Writer, data any) error {
	rows, keys := toRows(data)
	if len(rows) == 0 {
		fmt.Fprintln(w, "(no results)")
		return nil
	}

	// Calculate column widths
	widths := make(map[string]int)
	for _, k := range keys {
		widths[k] = len(k)
	}
	for _, row := range rows {
		for _, k := range keys {
			s := fmt.Sprintf("%v", row[k])
			if len(s) > widths[k] {
				widths[k] = len(s)
			}
		}
	}

	// Header
	for i, k := range keys {
		if i > 0 {
			fmt.Fprint(w, " | ")
		}
		fmt.Fprintf(w, "%-*s", widths[k], k)
	}
	fmt.Fprintln(w)

	// Separator
	for i, k := range keys {
		if i > 0 {
			fmt.Fprint(w, "-+-")
		}
		fmt.Fprint(w, strings.Repeat("-", widths[k]))
	}
	fmt.Fprintln(w)

	// Rows
	for _, row := range rows {
		for i, k := range keys {
			if i > 0 {
				fmt.Fprint(w, " | ")
			}
			fmt.Fprintf(w, "%-*s", widths[k], fmt.Sprintf("%v", row[k]))
		}
		fmt.Fprintln(w)
	}
	return nil
}

func writeCSV(w io.Writer, data any) error {
	rows, keys := toRows(data)
	if len(rows) == 0 {
		return nil
	}

	cw := csv.NewWriter(w)
	defer cw.Flush()

	if err := cw.Write(keys); err != nil {
		return err
	}
	for _, row := range rows {
		record := make([]string, len(keys))
		for i, k := range keys {
			record[i] = fmt.Sprintf("%v", row[k])
		}
		if err := cw.Write(record); err != nil {
			return err
		}
	}
	return nil
}

func toRows(data any) ([]map[string]any, []string) {
	switch v := data.(type) {
	case []map[string]any:
		return v, collectKeys(v)
	case map[string]any:
		return []map[string]any{v}, collectKeysFromMap(v)
	case []any:
		var rows []map[string]any
		for _, item := range v {
			if m, ok := item.(map[string]any); ok {
				rows = append(rows, m)
			}
		}
		return rows, collectKeys(rows)
	default:
		// Try JSON round-trip
		b, err := json.Marshal(data)
		if err != nil {
			return nil, nil
		}
		var result any
		if err := json.Unmarshal(b, &result); err != nil {
			return nil, nil
		}
		if result != data {
			return toRows(result)
		}
		return nil, nil
	}
}

func collectKeys(rows []map[string]any) []string {
	seen := make(map[string]bool)
	var keys []string
	for _, row := range rows {
		for k := range row {
			if !seen[k] {
				seen[k] = true
				keys = append(keys, k)
			}
		}
	}
	sort.Strings(keys)
	return keys
}

func collectKeysFromMap(m map[string]any) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	return keys
}
