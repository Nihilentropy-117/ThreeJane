package sql

import (
	"math"
	"sort"

	"github.com/nihil/obsidian-base/internal/expr"
)

// Aggregate functions that operate on a slice of Values.

func AggCount(vals []*expr.Value) *expr.Value {
	return expr.NumberVal(float64(len(vals)))
}

func AggSum(vals []*expr.Value) *expr.Value {
	sum := 0.0
	for _, v := range vals {
		sum += v.ToNumber()
	}
	return expr.NumberVal(sum)
}

func AggAvg(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	sum := 0.0
	for _, v := range vals {
		sum += v.ToNumber()
	}
	return expr.NumberVal(sum / float64(len(vals)))
}

func AggMin(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	min := vals[0]
	for _, v := range vals[1:] {
		if v.Compare(min) < 0 {
			min = v
		}
	}
	return min
}

func AggMax(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	max := vals[0]
	for _, v := range vals[1:] {
		if v.Compare(max) > 0 {
			max = v
		}
	}
	return max
}

func AggMedian(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	nums := make([]float64, len(vals))
	for i, v := range vals {
		nums[i] = v.ToNumber()
	}
	sort.Float64s(nums)
	mid := len(nums) / 2
	if len(nums)%2 == 0 {
		return expr.NumberVal((nums[mid-1] + nums[mid]) / 2)
	}
	return expr.NumberVal(nums[mid])
}

func AggStddev(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	mean := 0.0
	for _, v := range vals {
		mean += v.ToNumber()
	}
	mean /= float64(len(vals))

	variance := 0.0
	for _, v := range vals {
		d := v.ToNumber() - mean
		variance += d * d
	}
	variance /= float64(len(vals))
	return expr.NumberVal(math.Sqrt(variance))
}

func AggRange(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	min, max := vals[0].ToNumber(), vals[0].ToNumber()
	for _, v := range vals[1:] {
		n := v.ToNumber()
		if n < min {
			min = n
		}
		if n > max {
			max = n
		}
	}
	return expr.NumberVal(max - min)
}

func AggEarliest(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	earliest := vals[0]
	for _, v := range vals[1:] {
		if v.Type == expr.TypeDate && (earliest.Type != expr.TypeDate || v.Date.Before(earliest.Date)) {
			earliest = v
		}
	}
	return earliest
}

func AggLatest(vals []*expr.Value) *expr.Value {
	if len(vals) == 0 {
		return expr.Null
	}
	latest := vals[0]
	for _, v := range vals[1:] {
		if v.Type == expr.TypeDate && (latest.Type != expr.TypeDate || v.Date.After(latest.Date)) {
			latest = v
		}
	}
	return latest
}

func AggChecked(vals []*expr.Value) *expr.Value {
	count := 0
	for _, v := range vals {
		if v.IsTruthy() {
			count++
		}
	}
	return expr.NumberVal(float64(count))
}

func AggUnchecked(vals []*expr.Value) *expr.Value {
	count := 0
	for _, v := range vals {
		if !v.IsTruthy() {
			count++
		}
	}
	return expr.NumberVal(float64(count))
}

func AggEmpty(vals []*expr.Value) *expr.Value {
	count := 0
	for _, v := range vals {
		if v.IsEmpty() {
			count++
		}
	}
	return expr.NumberVal(float64(count))
}

func AggFilled(vals []*expr.Value) *expr.Value {
	count := 0
	for _, v := range vals {
		if !v.IsEmpty() {
			count++
		}
	}
	return expr.NumberVal(float64(count))
}

func AggUnique(vals []*expr.Value) *expr.Value {
	seen := make(map[string]bool)
	var unique []*expr.Value
	for _, v := range vals {
		key := v.ToString()
		if !seen[key] {
			seen[key] = true
			unique = append(unique, v)
		}
	}
	return expr.ListVal(unique)
}
