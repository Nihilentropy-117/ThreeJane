package sql

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"github.com/nihil/obsidian-base/internal/base"
	"github.com/nihil/obsidian-base/internal/expr"
	oerr "github.com/nihil/obsidian-base/internal/errors"
	"github.com/nihil/obsidian-base/internal/vault"
)

// Executor runs SQL statements against a vault.
type Executor struct {
	Vault      *vault.Vault
	HardDelete bool
	Yes        bool // skip confirmation
	Folder     string // override folder for INSERT
}

// ExecResult is the result of executing a SQL statement.
type ExecResult struct {
	Rows    []map[string]any `json:"rows,omitempty"`
	Created string           `json:"created,omitempty"`
	Updated int              `json:"updated,omitempty"`
	Deleted int              `json:"deleted,omitempty"`
	Message string           `json:"message,omitempty"`
}

func (e *Executor) Execute(stmt Statement) (*ExecResult, error) {
	switch s := stmt.(type) {
	case *SelectStmt:
		return e.execSelect(s)
	case *InsertStmt:
		return e.execInsert(s)
	case *UpdateStmt:
		return e.execUpdate(s)
	case *DeleteStmt:
		return e.execDelete(s)
	default:
		return nil, oerr.New(oerr.ParseError, "unknown statement type")
	}
}

func (e *Executor) execSelect(stmt *SelectStmt) (*ExecResult, error) {
	b, notes, err := e.resolveBase(stmt.From)
	if err != nil {
		return nil, err
	}

	// Apply WHERE filter
	filtered := e.filterNotes(notes, stmt.Where, b)

	// Check for aggregates
	hasAgg := e.hasAggregates(stmt.Columns)

	if hasAgg && len(stmt.GroupBy) == 0 {
		// Aggregate over all rows
		row := e.computeAggregates(stmt.Columns, filtered, b)
		return &ExecResult{Rows: []map[string]any{row}}, nil
	}

	if len(stmt.GroupBy) > 0 {
		return e.execGroupBy(stmt, filtered, b)
	}

	// Regular SELECT
	// Sort
	if len(stmt.OrderBy) > 0 {
		e.sortNotes(filtered, stmt.OrderBy, b)
	}

	// Offset + Limit
	if stmt.Offset > 0 && stmt.Offset < len(filtered) {
		filtered = filtered[stmt.Offset:]
	}
	if stmt.HasLimit && stmt.Limit >= 0 && stmt.Limit < len(filtered) {
		filtered = filtered[:stmt.Limit]
	}

	// Project columns
	columns := e.resolveSelectColumns(stmt.Columns, b, filtered)
	rows := make([]map[string]any, len(filtered))
	for i, note := range filtered {
		rows[i] = e.projectNote(note, columns, b)
	}

	return &ExecResult{Rows: rows}, nil
}

func (e *Executor) execGroupBy(stmt *SelectStmt, notes []*vault.Note, b *base.Base) (*ExecResult, error) {
	groups := make(map[string][]*vault.Note)
	var order []string

	for _, note := range notes {
		key := ""
		for _, col := range stmt.GroupBy {
			val := e.getNoteValue(note, col, b)
			key += val.ToString() + "|"
		}
		if _, exists := groups[key]; !exists {
			order = append(order, key)
		}
		groups[key] = append(groups[key], note)
	}

	var rows []map[string]any
	for _, key := range order {
		groupNotes := groups[key]
		row := e.computeAggregates(stmt.Columns, groupNotes, b)
		// Add group by columns
		if len(groupNotes) > 0 {
			for _, col := range stmt.GroupBy {
				val := e.getNoteValue(groupNotes[0], col, b)
				row[col] = val.ToGoValue()
			}
		}
		rows = append(rows, row)
	}

	return &ExecResult{Rows: rows}, nil
}

func (e *Executor) execInsert(stmt *InsertStmt) (*ExecResult, error) {
	b, _, err := e.resolveBase(stmt.Table)
	if err != nil {
		return nil, err
	}

	// Build properties from columns and values
	props := make(map[string]any)
	var fileName string

	for i, col := range stmt.Columns {
		val := e.evalSQLExpr(stmt.Values[i])
		if strings.EqualFold(col, "name") || col == "file.name" {
			fileName = val.ToString()
		} else {
			// Try to parse JSON arrays/objects for complex values
			goVal := val.ToGoValue()
			if val.Type == expr.TypeString {
				// Try JSON parse for arrays like '["a","b"]'
				var parsed any
				if err := json.Unmarshal([]byte(val.Str), &parsed); err == nil {
					goVal = parsed
				}
			}
			props[col] = goVal
		}
	}

	if fileName == "" {
		return nil, oerr.New(oerr.ParseError, "INSERT requires a 'name' column for the file name")
	}

	// Determine folder
	folder := e.Folder
	if folder == "" {
		folder = filepath.Dir(b.Path)
	} else {
		folder = filepath.Join(e.Vault.Root, folder)
	}

	// Create the file
	filePath := filepath.Join(folder, fileName+".md")

	// Check the note would match the base filters
	note := &vault.Note{
		FilePath:   filePath,
		Properties: props,
		VaultRoot:  e.Vault.Root,
	}

	if !base.EvalFilter(b.Filters, note, e.Vault.Root) {
		return nil, oerr.New(oerr.FilterMismatch,
			fmt.Sprintf("new note would not match base filters for '%s'", b.Name))
	}

	// Write the file
	content := vault.WriteFrontmatter(props, fmt.Sprintf("\n# %s\n", fileName))

	if err := os.MkdirAll(filepath.Dir(filePath), 0755); err != nil {
		return nil, oerr.Newf(oerr.WriteError, "failed to create directory: %v", err)
	}
	if err := os.WriteFile(filePath, []byte(content), 0644); err != nil {
		return nil, oerr.Newf(oerr.WriteError, "failed to write file: %v", err)
	}

	relPath, _ := filepath.Rel(e.Vault.Root, filePath)
	return &ExecResult{Created: relPath}, nil
}

func (e *Executor) execUpdate(stmt *UpdateStmt) (*ExecResult, error) {
	b, notes, err := e.resolveBase(stmt.Table)
	if err != nil {
		return nil, err
	}

	filtered := e.filterNotes(notes, stmt.Where, b)

	count := 0
	for _, note := range filtered {
		modified := false
		for _, assign := range stmt.Assignments {
			val := e.evalSQLExpr(assign.Value)
			goVal := val.ToGoValue()
			if val.Type == expr.TypeString {
				var parsed any
				if err := json.Unmarshal([]byte(val.Str), &parsed); err == nil {
					goVal = parsed
				}
			}
			note.Properties[assign.Column] = goVal
			modified = true
		}
		if modified {
			content := vault.WriteFrontmatter(note.Properties, note.Body)
			if err := os.WriteFile(note.FilePath, []byte(content), 0644); err != nil {
				return nil, oerr.Newf(oerr.WriteError, "failed to update %s: %v", note.FilePath, err)
			}
			count++
		}
	}

	return &ExecResult{Updated: count}, nil
}

func (e *Executor) execDelete(stmt *DeleteStmt) (*ExecResult, error) {
	b, notes, err := e.resolveBase(stmt.Table)
	if err != nil {
		return nil, err
	}

	filtered := e.filterNotes(notes, stmt.Where, b)

	if len(filtered) == 0 {
		return &ExecResult{Deleted: 0, Message: "no matching notes found"}, nil
	}

	if !e.Yes {
		return &ExecResult{
			Deleted: len(filtered),
			Message: fmt.Sprintf("would delete %d note(s). Use --yes to confirm.", len(filtered)),
		}, nil
	}

	count := 0
	for _, note := range filtered {
		if e.HardDelete {
			if err := os.Remove(note.FilePath); err != nil {
				return nil, oerr.Newf(oerr.WriteError, "failed to delete %s: %v", note.FilePath, err)
			}
		} else {
			// Unlink: remove properties that cause the note to match the filter
			// For simplicity, clear all properties
			content := vault.WriteFrontmatter(make(map[string]any), note.Body)
			if err := os.WriteFile(note.FilePath, []byte(content), 0644); err != nil {
				return nil, oerr.Newf(oerr.WriteError, "failed to unlink %s: %v", note.FilePath, err)
			}
		}
		count++
	}

	return &ExecResult{Deleted: count}, nil
}

// Helper methods

func (e *Executor) resolveBase(name string) (*base.Base, []*vault.Note, error) {
	basePath := e.Vault.FindBase(name)
	if basePath == "" {
		names := e.Vault.BaseNames()
		return nil, nil, oerr.WithSuggestion(oerr.BaseNotFound,
			fmt.Sprintf("no base file named '%s' found in vault", name),
			fmt.Sprintf("available bases: %s", strings.Join(names, ", ")))
	}

	b, err := base.Parse(basePath)
	if err != nil {
		return nil, nil, oerr.Newf(oerr.ParseError, "failed to parse base file: %v", err)
	}

	notes := base.Resolve(b, e.Vault)
	return b, notes, nil
}

func (e *Executor) filterNotes(notes []*vault.Note, where Expr, b *base.Base) []*vault.Note {
	if where == nil {
		return notes
	}
	var result []*vault.Note
	for _, note := range notes {
		if e.evalWhere(note, where, b) {
			result = append(result, note)
		}
	}
	return result
}

func (e *Executor) evalWhere(note *vault.Note, expr Expr, b *base.Base) bool {
	val := e.evalWhereExpr(note, expr, b)
	return val.IsTruthy()
}

func (e *Executor) evalWhereExpr(note *vault.Note, ex Expr, b *base.Base) *expr.Value {
	switch x := ex.(type) {
	case *BinaryExpr:
		left := e.evalWhereExpr(note, x.Left, b)
		right := e.evalWhereExpr(note, x.Right, b)
		switch x.Op {
		case "AND":
			return expr.BoolVal(left.IsTruthy() && right.IsTruthy())
		case "OR":
			return expr.BoolVal(left.IsTruthy() || right.IsTruthy())
		case "=":
			return expr.BoolVal(left.Equals(right))
		case "!=":
			return expr.BoolVal(!left.Equals(right))
		case "<":
			return expr.BoolVal(left.Compare(right) < 0)
		case "<=":
			return expr.BoolVal(left.Compare(right) <= 0)
		case ">":
			return expr.BoolVal(left.Compare(right) > 0)
		case ">=":
			return expr.BoolVal(left.Compare(right) >= 0)
		}

	case *UnaryExpr:
		if x.Op == "NOT" {
			val := e.evalWhereExpr(note, x.Operand, b)
			return expr.BoolVal(!val.IsTruthy())
		}

	case *ContainsExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		val := e.evalWhereExpr(note, x.Value, b)
		return expr.BoolVal(col.ListContains(val))

	case *ContainsAllExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		for _, v := range x.Values {
			val := e.evalWhereExpr(note, v, b)
			if !col.ListContains(val) {
				return expr.BoolVal(false)
			}
		}
		return expr.BoolVal(true)

	case *ContainsAnyExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		for _, v := range x.Values {
			val := e.evalWhereExpr(note, v, b)
			if col.ListContains(val) {
				return expr.BoolVal(true)
			}
		}
		return expr.BoolVal(false)

	case *IsEmptyExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		empty := col.IsEmpty()
		if x.Not {
			return expr.BoolVal(!empty)
		}
		return expr.BoolVal(empty)

	case *IsNullExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		isNull := col.IsNull
		if x.Not {
			return expr.BoolVal(!isNull)
		}
		return expr.BoolVal(isNull)

	case *LikeExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		pat := e.evalWhereExpr(note, x.Pattern, b)
		return expr.BoolVal(matchLike(col.ToString(), pat.ToString()))

	case *StartsWithExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		val := e.evalWhereExpr(note, x.Value, b)
		return expr.BoolVal(strings.HasPrefix(col.ToString(), val.ToString()))

	case *EndsWithExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		val := e.evalWhereExpr(note, x.Value, b)
		return expr.BoolVal(strings.HasSuffix(col.ToString(), val.ToString()))

	case *MatchesExpr:
		col := e.evalWhereExpr(note, x.Column, b)
		pat := e.evalWhereExpr(note, x.Pattern, b)
		patStr := pat.ToString()
		// Strip surrounding slashes if present
		patStr = strings.TrimPrefix(patStr, "/")
		patStr = strings.TrimSuffix(patStr, "/")
		re, err := regexp.Compile(patStr)
		if err != nil {
			return expr.BoolVal(false)
		}
		return expr.BoolVal(re.MatchString(col.ToString()))

	case *FuncExpr:
		return e.evalFuncExpr(note, x, b)

	case *ColumnRef:
		return e.getNoteValue(note, x.Name, b)

	case *StringLit:
		return expr.StringVal(x.Value)

	case *NumberLit:
		return expr.NumberVal(x.Value)

	case *BoolLit:
		return expr.BoolVal(x.Value)

	case *NullLit:
		return expr.Null
	}

	return expr.Null
}

func (e *Executor) evalFuncExpr(note *vault.Note, f *FuncExpr, b *base.Base) *expr.Value {
	switch f.Name {
	case "HAS_TAG":
		tags := note.Tags()
		for _, arg := range f.Args {
			val := e.evalWhereExpr(note, arg, b)
			tag := val.ToString()
			found := false
			for _, t := range tags {
				if strings.EqualFold(t, tag) {
					found = true
					break
				}
			}
			if !found {
				return expr.BoolVal(false)
			}
		}
		return expr.BoolVal(true)

	case "IN_FOLDER":
		if len(f.Args) > 0 {
			val := e.evalWhereExpr(note, f.Args[0], b)
			folder := val.ToString()
			noteFolder := note.FileFolderRel()
			return expr.BoolVal(noteFolder == folder || strings.HasPrefix(noteFolder, folder+"/"))
		}

	case "HAS_LINK":
		if len(f.Args) > 0 {
			val := e.evalWhereExpr(note, f.Args[0], b)
			target := val.ToString()
			for _, l := range note.Links() {
				if strings.EqualFold(l, target) {
					return expr.BoolVal(true)
				}
			}
			return expr.BoolVal(false)
		}

	case "HAS_PROPERTY":
		if len(f.Args) > 0 {
			val := e.evalWhereExpr(note, f.Args[0], b)
			prop := val.ToString()
			_, ok := note.Properties[prop]
			return expr.BoolVal(ok)
		}

	// Aggregate functions used in WHERE (unusual but handle gracefully)
	case "COUNT", "SUM", "AVG", "MIN", "MAX", "MEDIAN", "STDDEV", "RANGE",
		"EARLIEST", "LATEST", "CHECKED", "UNCHECKED", "EMPTY", "FILLED", "UNIQUE":
		return expr.Null
	}

	return expr.Null
}

func (e *Executor) getNoteValue(note *vault.Note, name string, b *base.Base) *expr.Value {
	if name == "*" {
		return expr.Null
	}

	// Formula properties
	if strings.HasPrefix(name, "formula.") {
		formulaName := strings.TrimPrefix(name, "formula.")
		if formulaExpr, ok := b.Formulas[formulaName]; ok {
			ctx := base.BuildNoteContext(note, e.Vault.Root)
			val, err := expr.EvalExpression(formulaExpr, ctx)
			if err != nil {
				return expr.Null
			}
			return val
		}
		return expr.Null
	}

	// File properties
	if strings.HasPrefix(name, "file.") {
		val := note.GetProperty(name)
		return expr.GoToValue(val)
	}

	// Note properties
	val := note.GetProperty(name)
	return expr.GoToValue(val)
}

func (e *Executor) resolveSelectColumns(cols []SelectColumn, b *base.Base, notes []*vault.Note) []string {
	var result []string
	for _, col := range cols {
		if col.Star {
			// Include all known columns
			result = append(result, "file.name")
			seen := map[string]bool{"file.name": true}
			for _, note := range notes {
				for k := range note.Properties {
					if !seen[k] {
						seen[k] = true
						result = append(result, k)
					}
				}
			}
			for k := range b.Formulas {
				name := "formula." + k
				if !seen[name] {
					seen[name] = true
					result = append(result, name)
				}
			}
			return result
		}

		name := e.exprToColumnName(col)
		if name != "" {
			result = append(result, name)
		}
	}
	return result
}

func (e *Executor) exprToColumnName(col SelectColumn) string {
	if col.Alias != "" {
		return col.Alias
	}
	switch x := col.Expr.(type) {
	case *ColumnRef:
		return x.Name
	case *FuncExpr:
		if len(x.Args) == 1 {
			if cr, ok := x.Args[0].(*ColumnRef); ok {
				return fmt.Sprintf("%s(%s)", x.Name, cr.Name)
			}
		}
		if x.Name == "COUNT" && len(x.Args) == 1 {
			if cr, ok := x.Args[0].(*ColumnRef); ok && cr.Name == "*" {
				return "COUNT(*)"
			}
		}
		return x.Name
	}
	return ""
}

func (e *Executor) projectNote(note *vault.Note, columns []string, b *base.Base) map[string]any {
	row := make(map[string]any, len(columns))
	for _, col := range columns {
		val := e.getNoteValue(note, col, b)
		row[col] = val.ToGoValue()
	}
	return row
}

func (e *Executor) hasAggregates(cols []SelectColumn) bool {
	for _, col := range cols {
		if e.isAggExpr(col.Expr) {
			return true
		}
	}
	return false
}

func (e *Executor) isAggExpr(ex Expr) bool {
	f, ok := ex.(*FuncExpr)
	if !ok {
		return false
	}
	switch f.Name {
	case "COUNT", "SUM", "AVG", "MIN", "MAX", "MEDIAN", "STDDEV", "RANGE",
		"EARLIEST", "LATEST", "CHECKED", "UNCHECKED", "EMPTY", "FILLED", "UNIQUE":
		return true
	}
	return false
}

func (e *Executor) computeAggregates(cols []SelectColumn, notes []*vault.Note, b *base.Base) map[string]any {
	row := make(map[string]any)
	for _, col := range cols {
		f, ok := col.Expr.(*FuncExpr)
		if !ok {
			continue
		}
		name := e.exprToColumnName(col)

		// Collect values
		var vals []*expr.Value
		if f.Name == "COUNT" && len(f.Args) == 1 {
			if cr, ok := f.Args[0].(*ColumnRef); ok && cr.Name == "*" {
				row[name] = len(notes)
				continue
			}
		}

		for _, note := range notes {
			if len(f.Args) > 0 {
				if cr, ok := f.Args[0].(*ColumnRef); ok {
					v := e.getNoteValue(note, cr.Name, b)
					if !v.IsNull {
						vals = append(vals, v)
					}
				}
			}
		}

		var result *expr.Value
		switch f.Name {
		case "COUNT":
			result = AggCount(vals)
		case "SUM":
			result = AggSum(vals)
		case "AVG":
			result = AggAvg(vals)
		case "MIN":
			result = AggMin(vals)
		case "MAX":
			result = AggMax(vals)
		case "MEDIAN":
			result = AggMedian(vals)
		case "STDDEV":
			result = AggStddev(vals)
		case "RANGE":
			result = AggRange(vals)
		case "EARLIEST":
			result = AggEarliest(vals)
		case "LATEST":
			result = AggLatest(vals)
		case "CHECKED":
			result = AggChecked(vals)
		case "UNCHECKED":
			result = AggUnchecked(vals)
		case "EMPTY":
			result = AggEmpty(vals)
		case "FILLED":
			result = AggFilled(vals)
		case "UNIQUE":
			result = AggUnique(vals)
		default:
			result = expr.Null
		}

		row[name] = result.ToGoValue()
	}
	return row
}

func (e *Executor) sortNotes(notes []*vault.Note, orderBy []OrderByClause, b *base.Base) {
	sort.SliceStable(notes, func(i, j int) bool {
		for _, ob := range orderBy {
			vi := e.getNoteValue(notes[i], ob.Column, b)
			vj := e.getNoteValue(notes[j], ob.Column, b)
			cmp := vi.Compare(vj)
			if cmp == 0 {
				continue
			}
			if ob.Desc {
				return cmp > 0
			}
			return cmp < 0
		}
		return false
	})
}

func (e *Executor) evalSQLExpr(ex Expr) *expr.Value {
	switch x := ex.(type) {
	case *StringLit:
		return expr.StringVal(x.Value)
	case *NumberLit:
		return expr.NumberVal(x.Value)
	case *BoolLit:
		return expr.BoolVal(x.Value)
	case *NullLit:
		return expr.Null
	}
	return expr.Null
}

func matchLike(s, pattern string) bool {
	// Convert SQL LIKE pattern to regex
	// % = .*, _ = .
	var re strings.Builder
	re.WriteString("(?i)^")
	for _, ch := range pattern {
		switch ch {
		case '%':
			re.WriteString(".*")
		case '_':
			re.WriteString(".")
		case '.', '(', ')', '[', ']', '{', '}', '+', '?', '^', '$', '|', '\\':
			re.WriteRune('\\')
			re.WriteRune(ch)
		default:
			re.WriteRune(ch)
		}
	}
	re.WriteString("$")
	r, err := regexp.Compile(re.String())
	if err != nil {
		return false
	}
	return r.MatchString(s)
}
