package sql

import (
	"fmt"
	"strings"
)

type TokenType int

const (
	// Literals
	TokNumber TokenType = iota
	TokString
	TokIdent
	TokStar

	// Keywords
	TokSelect
	TokFrom
	TokWhere
	TokAnd
	TokOr
	TokNot
	TokOrder
	TokBy
	TokAsc
	TokDesc
	TokLimit
	TokOffset
	TokGroup
	TokInsert
	TokInto
	TokValues
	TokUpdate
	TokSet
	TokDelete
	TokAs
	TokIs
	TokNull
	TokLike
	TokIn
	TokBetween
	TokTrue
	TokFalse

	// Extended keywords
	TokContains
	TokContainsAll
	TokContainsAny
	TokHasTag
	TokInFolder
	TokHasLink
	TokHasProperty
	TokStartsWith
	TokEndsWith
	TokMatches
	TokEmpty

	// Operators
	TokEq
	TokNeq
	TokLt
	TokLte
	TokGt
	TokGte

	// Delimiters
	TokLParen
	TokRParen
	TokComma
	TokDot

	TokEOF
)

type Token struct {
	Type TokenType
	Val  string
	Pos  int
}

func (t Token) String() string {
	return fmt.Sprintf("{%d %q}", t.Type, t.Val)
}

type Lexer struct {
	input  string
	pos    int
	tokens []Token
}

func NewLexer(input string) *Lexer {
	return &Lexer{input: input}
}

func (l *Lexer) Tokenize() ([]Token, error) {
	for l.pos < len(l.input) {
		l.skipWhitespace()
		if l.pos >= len(l.input) {
			break
		}

		ch := l.input[l.pos]

		switch {
		case ch >= '0' && ch <= '9':
			l.tokens = append(l.tokens, l.readNumber())
		case ch == '\'' || ch == '"':
			tok, err := l.readString()
			if err != nil {
				return nil, err
			}
			l.tokens = append(l.tokens, tok)
		case isIdentStart(ch):
			l.tokens = append(l.tokens, l.readIdentOrKeyword())
		case ch == '*':
			l.tokens = append(l.tokens, Token{TokStar, "*", l.pos})
			l.pos++
		case ch == '=' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokEq, "==", l.pos})
			l.pos += 2
		case ch == '=':
			l.tokens = append(l.tokens, Token{TokEq, "=", l.pos})
			l.pos++
		case ch == '!' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokNeq, "!=", l.pos})
			l.pos += 2
		case ch == '<' && l.peek(1) == '>':
			l.tokens = append(l.tokens, Token{TokNeq, "<>", l.pos})
			l.pos += 2
		case ch == '<' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokLte, "<=", l.pos})
			l.pos += 2
		case ch == '<':
			l.tokens = append(l.tokens, Token{TokLt, "<", l.pos})
			l.pos++
		case ch == '>' && l.peek(1) == '=':
			l.tokens = append(l.tokens, Token{TokGte, ">=", l.pos})
			l.pos += 2
		case ch == '>':
			l.tokens = append(l.tokens, Token{TokGt, ">", l.pos})
			l.pos++
		case ch == '(':
			l.tokens = append(l.tokens, Token{TokLParen, "(", l.pos})
			l.pos++
		case ch == ')':
			l.tokens = append(l.tokens, Token{TokRParen, ")", l.pos})
			l.pos++
		case ch == ',':
			l.tokens = append(l.tokens, Token{TokComma, ",", l.pos})
			l.pos++
		case ch == '.':
			l.tokens = append(l.tokens, Token{TokDot, ".", l.pos})
			l.pos++
		default:
			return nil, fmt.Errorf("unexpected character '%c' at position %d", ch, l.pos)
		}
	}

	l.tokens = append(l.tokens, Token{TokEOF, "", l.pos})
	return l.tokens, nil
}

func (l *Lexer) skipWhitespace() {
	for l.pos < len(l.input) && (l.input[l.pos] == ' ' || l.input[l.pos] == '\t' || l.input[l.pos] == '\n' || l.input[l.pos] == '\r') {
		l.pos++
	}
}

func (l *Lexer) peek(offset int) byte {
	idx := l.pos + offset
	if idx < len(l.input) {
		return l.input[idx]
	}
	return 0
}

func (l *Lexer) readNumber() Token {
	start := l.pos
	for l.pos < len(l.input) && (l.input[l.pos] >= '0' && l.input[l.pos] <= '9') {
		l.pos++
	}
	if l.pos < len(l.input) && l.input[l.pos] == '.' {
		l.pos++
		for l.pos < len(l.input) && (l.input[l.pos] >= '0' && l.input[l.pos] <= '9') {
			l.pos++
		}
	}
	return Token{TokNumber, l.input[start:l.pos], start}
}

func (l *Lexer) readString() (Token, error) {
	quote := l.input[l.pos]
	start := l.pos
	l.pos++

	var sb strings.Builder
	for l.pos < len(l.input) {
		ch := l.input[l.pos]
		if ch == '\\' && l.pos+1 < len(l.input) {
			l.pos++
			sb.WriteByte(l.input[l.pos])
			l.pos++
			continue
		}
		if ch == quote {
			l.pos++
			return Token{TokString, sb.String(), start}, nil
		}
		sb.WriteByte(ch)
		l.pos++
	}
	return Token{}, fmt.Errorf("unterminated string at position %d", start)
}

func (l *Lexer) readIdentOrKeyword() Token {
	start := l.pos
	for l.pos < len(l.input) && isIdentPart(l.input[l.pos]) {
		l.pos++
	}
	val := l.input[start:l.pos]
	upper := strings.ToUpper(val)

	switch upper {
	case "SELECT":
		return Token{TokSelect, val, start}
	case "FROM":
		return Token{TokFrom, val, start}
	case "WHERE":
		return Token{TokWhere, val, start}
	case "AND":
		return Token{TokAnd, val, start}
	case "OR":
		return Token{TokOr, val, start}
	case "NOT":
		return Token{TokNot, val, start}
	case "ORDER":
		return Token{TokOrder, val, start}
	case "BY":
		return Token{TokBy, val, start}
	case "ASC":
		return Token{TokAsc, val, start}
	case "DESC":
		return Token{TokDesc, val, start}
	case "LIMIT":
		return Token{TokLimit, val, start}
	case "OFFSET":
		return Token{TokOffset, val, start}
	case "GROUP":
		return Token{TokGroup, val, start}
	case "INSERT":
		return Token{TokInsert, val, start}
	case "INTO":
		return Token{TokInto, val, start}
	case "VALUES":
		return Token{TokValues, val, start}
	case "UPDATE":
		return Token{TokUpdate, val, start}
	case "SET":
		return Token{TokSet, val, start}
	case "DELETE":
		return Token{TokDelete, val, start}
	case "AS":
		return Token{TokAs, val, start}
	case "IS":
		return Token{TokIs, val, start}
	case "NULL":
		return Token{TokNull, val, start}
	case "LIKE":
		return Token{TokLike, val, start}
	case "IN":
		return Token{TokIn, val, start}
	case "BETWEEN":
		return Token{TokBetween, val, start}
	case "TRUE":
		return Token{TokTrue, val, start}
	case "FALSE":
		return Token{TokFalse, val, start}
	case "CONTAINS":
		return Token{TokContains, val, start}
	case "CONTAINS_ALL":
		return Token{TokContainsAll, val, start}
	case "CONTAINS_ANY":
		return Token{TokContainsAny, val, start}
	case "HAS_TAG":
		return Token{TokHasTag, val, start}
	case "IN_FOLDER":
		return Token{TokInFolder, val, start}
	case "HAS_LINK":
		return Token{TokHasLink, val, start}
	case "HAS_PROPERTY":
		return Token{TokHasProperty, val, start}
	case "STARTS_WITH":
		return Token{TokStartsWith, val, start}
	case "ENDS_WITH":
		return Token{TokEndsWith, val, start}
	case "MATCHES":
		return Token{TokMatches, val, start}
	case "EMPTY":
		return Token{TokEmpty, val, start}
	}

	return Token{TokIdent, val, start}
}

func isIdentStart(ch byte) bool {
	return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '_'
}

func isIdentPart(ch byte) bool {
	return isIdentStart(ch) || (ch >= '0' && ch <= '9') || ch == '_'
}
