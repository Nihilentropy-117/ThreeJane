package sql

import (
	"fmt"
	"strconv"
	"strings"
)

type Parser struct {
	tokens []Token
	pos    int
}

func NewParser(tokens []Token) *Parser {
	return &Parser{tokens: tokens}
}

func (p *Parser) current() Token {
	if p.pos < len(p.tokens) {
		return p.tokens[p.pos]
	}
	return Token{Type: TokEOF}
}

func (p *Parser) advance() Token {
	tok := p.current()
	if p.pos < len(p.tokens) {
		p.pos++
	}
	return tok
}

func (p *Parser) expect(typ TokenType) (Token, error) {
	tok := p.current()
	if tok.Type != typ {
		return tok, fmt.Errorf("expected token type %d but got %s at position %d", typ, tok.Val, tok.Pos)
	}
	p.advance()
	return tok, nil
}

func (p *Parser) isKeyword(val string) bool {
	return strings.EqualFold(p.current().Val, val)
}

// Parse parses a SQL statement.
func (p *Parser) Parse() (Statement, error) {
	switch p.current().Type {
	case TokSelect:
		return p.parseSelect()
	case TokInsert:
		return p.parseInsert()
	case TokUpdate:
		return p.parseUpdate()
	case TokDelete:
		return p.parseDelete()
	default:
		return nil, fmt.Errorf("expected SELECT, INSERT, UPDATE, or DELETE at position %d", p.current().Pos)
	}
}

func (p *Parser) parseSelect() (*SelectStmt, error) {
	p.advance() // consume SELECT

	stmt := &SelectStmt{Limit: -1}

	// Parse column list
	cols, err := p.parseSelectColumns()
	if err != nil {
		return nil, err
	}
	stmt.Columns = cols

	// FROM
	if p.current().Type != TokFrom {
		return nil, fmt.Errorf("expected FROM at position %d", p.current().Pos)
	}
	p.advance()

	// Table name
	tableName, err := p.parseTableName()
	if err != nil {
		return nil, err
	}
	stmt.From = tableName

	// Optional WHERE
	if p.current().Type == TokWhere {
		p.advance()
		where, err := p.parseExpr()
		if err != nil {
			return nil, err
		}
		stmt.Where = where
	}

	// Optional GROUP BY
	if p.current().Type == TokGroup {
		p.advance()
		if _, err := p.expect(TokBy); err != nil {
			return nil, err
		}
		for {
			col, err := p.parseColumnName()
			if err != nil {
				return nil, err
			}
			stmt.GroupBy = append(stmt.GroupBy, col)
			if p.current().Type != TokComma {
				break
			}
			p.advance()
		}
	}

	// Optional ORDER BY
	if p.current().Type == TokOrder {
		p.advance()
		if _, err := p.expect(TokBy); err != nil {
			return nil, err
		}
		for {
			col, err := p.parseColumnName()
			if err != nil {
				return nil, err
			}
			desc := false
			if p.current().Type == TokDesc {
				desc = true
				p.advance()
			} else if p.current().Type == TokAsc {
				p.advance()
			}
			stmt.OrderBy = append(stmt.OrderBy, OrderByClause{Column: col, Desc: desc})
			if p.current().Type != TokComma {
				break
			}
			p.advance()
		}
	}

	// Optional LIMIT
	if p.current().Type == TokLimit {
		p.advance()
		tok, err := p.expect(TokNumber)
		if err != nil {
			return nil, err
		}
		n, _ := strconv.Atoi(tok.Val)
		stmt.Limit = n
		stmt.HasLimit = true
	}

	// Optional OFFSET
	if p.current().Type == TokOffset {
		p.advance()
		tok, err := p.expect(TokNumber)
		if err != nil {
			return nil, err
		}
		n, _ := strconv.Atoi(tok.Val)
		stmt.Offset = n
	}

	return stmt, nil
}

func (p *Parser) parseSelectColumns() ([]SelectColumn, error) {
	var cols []SelectColumn

	if p.current().Type == TokStar {
		p.advance()
		cols = append(cols, SelectColumn{Star: true})
		return cols, nil
	}

	for {
		col, err := p.parseSelectColumn()
		if err != nil {
			return nil, err
		}
		cols = append(cols, col)
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}
	return cols, nil
}

func (p *Parser) parseSelectColumn() (SelectColumn, error) {
	expr, err := p.parseExpr()
	if err != nil {
		return SelectColumn{}, err
	}

	col := SelectColumn{Expr: expr}

	// Optional alias
	if p.current().Type == TokAs {
		p.advance()
		tok := p.advance()
		col.Alias = tok.Val
	}

	return col, nil
}

func (p *Parser) parseTableName() (string, error) {
	tok := p.current()
	if tok.Type != TokIdent {
		return "", fmt.Errorf("expected table name at position %d", tok.Pos)
	}
	name := p.advance().Val

	// Handle dotted names like schema.table (but we use it for base names)
	for p.current().Type == TokDot {
		p.advance()
		next := p.advance()
		name += "." + next.Val
	}

	return name, nil
}

func (p *Parser) parseColumnName() (string, error) {
	tok := p.current()
	if tok.Type != TokIdent {
		return "", fmt.Errorf("expected column name at position %d, got %s", tok.Pos, tok.Val)
	}
	name := p.advance().Val

	// Handle dotted names like file.name, formula.ppu
	for p.current().Type == TokDot {
		p.advance()
		next := p.advance()
		name += "." + next.Val
	}

	return name, nil
}

func (p *Parser) parseInsert() (*InsertStmt, error) {
	p.advance() // INSERT
	if _, err := p.expect(TokInto); err != nil {
		return nil, err
	}

	tableName, err := p.parseTableName()
	if err != nil {
		return nil, err
	}

	stmt := &InsertStmt{Table: tableName}

	// Column list
	if _, err := p.expect(TokLParen); err != nil {
		return nil, err
	}
	for {
		col, err := p.parseColumnName()
		if err != nil {
			return nil, err
		}
		stmt.Columns = append(stmt.Columns, col)
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}
	if _, err := p.expect(TokRParen); err != nil {
		return nil, err
	}

	// VALUES
	if _, err := p.expect(TokValues); err != nil {
		return nil, err
	}
	if _, err := p.expect(TokLParen); err != nil {
		return nil, err
	}
	for {
		val, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		stmt.Values = append(stmt.Values, val)
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}
	if _, err := p.expect(TokRParen); err != nil {
		return nil, err
	}

	if len(stmt.Columns) != len(stmt.Values) {
		return nil, fmt.Errorf("column count (%d) does not match value count (%d)", len(stmt.Columns), len(stmt.Values))
	}

	return stmt, nil
}

func (p *Parser) parseUpdate() (*UpdateStmt, error) {
	p.advance() // UPDATE

	tableName, err := p.parseTableName()
	if err != nil {
		return nil, err
	}

	stmt := &UpdateStmt{Table: tableName}

	if _, err := p.expect(TokSet); err != nil {
		return nil, err
	}

	// Assignments
	for {
		col, err := p.parseColumnName()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(TokEq); err != nil {
			return nil, err
		}
		val, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		stmt.Assignments = append(stmt.Assignments, Assignment{Column: col, Value: val})
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}

	// Optional WHERE
	if p.current().Type == TokWhere {
		p.advance()
		where, err := p.parseExpr()
		if err != nil {
			return nil, err
		}
		stmt.Where = where
	}

	return stmt, nil
}

func (p *Parser) parseDelete() (*DeleteStmt, error) {
	p.advance() // DELETE

	if _, err := p.expect(TokFrom); err != nil {
		return nil, err
	}

	tableName, err := p.parseTableName()
	if err != nil {
		return nil, err
	}

	stmt := &DeleteStmt{Table: tableName}

	// Optional WHERE
	if p.current().Type == TokWhere {
		p.advance()
		where, err := p.parseExpr()
		if err != nil {
			return nil, err
		}
		stmt.Where = where
	}

	return stmt, nil
}

// Expression parsing with precedence climbing

func (p *Parser) parseExpr() (Expr, error) {
	return p.parseOr()
}

func (p *Parser) parseOr() (Expr, error) {
	left, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokOr {
		p.advance()
		right, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: "OR", Left: left, Right: right}
	}
	return left, nil
}

func (p *Parser) parseAnd() (Expr, error) {
	left, err := p.parseNot()
	if err != nil {
		return nil, err
	}
	for p.current().Type == TokAnd {
		p.advance()
		right, err := p.parseNot()
		if err != nil {
			return nil, err
		}
		left = &BinaryExpr{Op: "AND", Left: left, Right: right}
	}
	return left, nil
}

func (p *Parser) parseNot() (Expr, error) {
	if p.current().Type == TokNot {
		p.advance()
		operand, err := p.parseNot()
		if err != nil {
			return nil, err
		}
		return &UnaryExpr{Op: "NOT", Operand: operand}, nil
	}
	return p.parseComparison()
}

func (p *Parser) parseComparison() (Expr, error) {
	left, err := p.parsePrimary()
	if err != nil {
		return nil, err
	}

	switch p.current().Type {
	case TokEq:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &BinaryExpr{Op: "=", Left: left, Right: right}, nil

	case TokNeq:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &BinaryExpr{Op: "!=", Left: left, Right: right}, nil

	case TokLt:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &BinaryExpr{Op: "<", Left: left, Right: right}, nil

	case TokLte:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &BinaryExpr{Op: "<=", Left: left, Right: right}, nil

	case TokGt:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &BinaryExpr{Op: ">", Left: left, Right: right}, nil

	case TokGte:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &BinaryExpr{Op: ">=", Left: left, Right: right}, nil

	case TokContains:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &ContainsExpr{Column: left, Value: right}, nil

	case TokContainsAll:
		p.advance()
		if _, err := p.expect(TokLParen); err != nil {
			return nil, err
		}
		args, err := p.parseExprList()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(TokRParen); err != nil {
			return nil, err
		}
		return &ContainsAllExpr{Column: left, Values: args}, nil

	case TokContainsAny:
		p.advance()
		if _, err := p.expect(TokLParen); err != nil {
			return nil, err
		}
		args, err := p.parseExprList()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(TokRParen); err != nil {
			return nil, err
		}
		return &ContainsAnyExpr{Column: left, Values: args}, nil

	case TokLike:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &LikeExpr{Column: left, Pattern: right}, nil

	case TokStartsWith:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &StartsWithExpr{Column: left, Value: right}, nil

	case TokEndsWith:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &EndsWithExpr{Column: left, Value: right}, nil

	case TokMatches:
		p.advance()
		right, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		return &MatchesExpr{Column: left, Pattern: right}, nil

	case TokIs:
		p.advance()
		if p.current().Type == TokNot {
			p.advance()
			if p.current().Type == TokEmpty {
				p.advance()
				return &IsEmptyExpr{Column: left, Not: true}, nil
			}
			if p.current().Type == TokNull {
				p.advance()
				return &IsNullExpr{Column: left, Not: true}, nil
			}
			return nil, fmt.Errorf("expected EMPTY or NULL after IS NOT at position %d", p.current().Pos)
		}
		if p.current().Type == TokEmpty {
			p.advance()
			return &IsEmptyExpr{Column: left, Not: false}, nil
		}
		if p.current().Type == TokNull {
			p.advance()
			return &IsNullExpr{Column: left, Not: false}, nil
		}
		return nil, fmt.Errorf("expected EMPTY or NULL after IS at position %d", p.current().Pos)
	}

	return left, nil
}

func (p *Parser) parsePrimary() (Expr, error) {
	tok := p.current()

	switch tok.Type {
	case TokNumber:
		p.advance()
		n, _ := strconv.ParseFloat(tok.Val, 64)
		return &NumberLit{Value: n}, nil

	case TokString:
		p.advance()
		return &StringLit{Value: tok.Val}, nil

	case TokTrue:
		p.advance()
		return &BoolLit{Value: true}, nil

	case TokFalse:
		p.advance()
		return &BoolLit{Value: false}, nil

	case TokNull:
		p.advance()
		return &NullLit{}, nil

	case TokStar:
		p.advance()
		return &ColumnRef{Name: "*"}, nil

	case TokLParen:
		p.advance()
		expr, err := p.parseExpr()
		if err != nil {
			return nil, err
		}
		if _, err := p.expect(TokRParen); err != nil {
			return nil, err
		}
		return expr, nil

	// Extended function-style keywords
	case TokHasTag:
		return p.parseFuncCall("HAS_TAG")
	case TokInFolder:
		return p.parseFuncCall("IN_FOLDER")
	case TokHasLink:
		return p.parseFuncCall("HAS_LINK")
	case TokHasProperty:
		return p.parseFuncCall("HAS_PROPERTY")

	case TokIdent:
		name := p.advance().Val
		// Check for dotted name
		for p.current().Type == TokDot {
			p.advance()
			next := p.advance()
			name += "." + next.Val
		}
		// Check if it's a function call
		if p.current().Type == TokLParen {
			p.advance()
			args, err := p.parseExprList()
			if err != nil {
				return nil, err
			}
			if _, err := p.expect(TokRParen); err != nil {
				return nil, err
			}
			return &FuncExpr{Name: strings.ToUpper(name), Args: args}, nil
		}
		return &ColumnRef{Name: name}, nil

	default:
		return nil, fmt.Errorf("unexpected token %q at position %d", tok.Val, tok.Pos)
	}
}

func (p *Parser) parseFuncCall(name string) (Expr, error) {
	p.advance() // consume keyword
	if _, err := p.expect(TokLParen); err != nil {
		return nil, err
	}
	args, err := p.parseExprList()
	if err != nil {
		return nil, err
	}
	if _, err := p.expect(TokRParen); err != nil {
		return nil, err
	}
	return &FuncExpr{Name: name, Args: args}, nil
}

func (p *Parser) parseExprList() ([]Expr, error) {
	var exprs []Expr
	if p.current().Type == TokRParen {
		return exprs, nil
	}
	for {
		expr, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		exprs = append(exprs, expr)
		if p.current().Type != TokComma {
			break
		}
		p.advance()
	}
	return exprs, nil
}

// ParseSQL is a convenience function to parse a SQL string.
func ParseSQL(input string) (Statement, error) {
	lexer := NewLexer(input)
	tokens, err := lexer.Tokenize()
	if err != nil {
		return nil, err
	}
	parser := NewParser(tokens)
	return parser.Parse()
}
