package sql

// Statement is the top-level SQL AST node.
type Statement interface {
	stmtType() string
}

// SelectStmt represents a SELECT query.
type SelectStmt struct {
	Columns  []SelectColumn
	From     string
	Where    Expr
	OrderBy  []OrderByClause
	GroupBy  []string
	Limit    int
	Offset   int
	HasLimit bool
}

func (s *SelectStmt) stmtType() string { return "select" }

// SelectColumn represents a column in the SELECT list.
type SelectColumn struct {
	Expr  Expr
	Alias string
	Star  bool // true for SELECT *
}

// OrderByClause represents an ORDER BY column.
type OrderByClause struct {
	Column string
	Desc   bool
}

// InsertStmt represents an INSERT INTO statement.
type InsertStmt struct {
	Table   string
	Columns []string
	Values  []Expr
}

func (s *InsertStmt) stmtType() string { return "insert" }

// UpdateStmt represents an UPDATE statement.
type UpdateStmt struct {
	Table       string
	Assignments []Assignment
	Where       Expr
}

func (s *UpdateStmt) stmtType() string { return "update" }

type Assignment struct {
	Column string
	Value  Expr
}

// DeleteStmt represents a DELETE statement.
type DeleteStmt struct {
	Table string
	Where Expr
}

func (s *DeleteStmt) stmtType() string { return "delete" }

// Expr is a SQL expression node.
type Expr interface {
	exprType() string
}

// ColumnRef is a column reference (e.g., file.name, rating, formula.ppu).
type ColumnRef struct {
	Name string // full dotted name
}

func (e *ColumnRef) exprType() string { return "column_ref" }

// StringLit is a string literal.
type StringLit struct {
	Value string
}

func (e *StringLit) exprType() string { return "string_lit" }

// NumberLit is a numeric literal.
type NumberLit struct {
	Value float64
}

func (e *NumberLit) exprType() string { return "number_lit" }

// BoolLit is a boolean literal.
type BoolLit struct {
	Value bool
}

func (e *BoolLit) exprType() string { return "bool_lit" }

// NullLit is a NULL literal.
type NullLit struct{}

func (e *NullLit) exprType() string { return "null_lit" }

// BinaryExpr is a binary operation (AND, OR, =, <, etc.).
type BinaryExpr struct {
	Op    string
	Left  Expr
	Right Expr
}

func (e *BinaryExpr) exprType() string { return "binary" }

// UnaryExpr is a unary operation (NOT).
type UnaryExpr struct {
	Op      string
	Operand Expr
}

func (e *UnaryExpr) exprType() string { return "unary" }

// FuncExpr is a function call (COUNT, AVG, HAS_TAG, etc.).
type FuncExpr struct {
	Name string
	Args []Expr
}

func (e *FuncExpr) exprType() string { return "func" }

// ContainsExpr represents `col CONTAINS 'value'`.
type ContainsExpr struct {
	Column Expr
	Value  Expr
}

func (e *ContainsExpr) exprType() string { return "contains" }

// ContainsAllExpr represents `col CONTAINS_ALL('a','b')`.
type ContainsAllExpr struct {
	Column Expr
	Values []Expr
}

func (e *ContainsAllExpr) exprType() string { return "contains_all" }

// ContainsAnyExpr represents `col CONTAINS_ANY('a','b')`.
type ContainsAnyExpr struct {
	Column Expr
	Values []Expr
}

func (e *ContainsAnyExpr) exprType() string { return "contains_any" }

// IsEmptyExpr represents `col IS EMPTY` or `col IS NOT EMPTY`.
type IsEmptyExpr struct {
	Column Expr
	Not    bool
}

func (e *IsEmptyExpr) exprType() string { return "is_empty" }

// LikeExpr represents `col LIKE 'pattern'`.
type LikeExpr struct {
	Column  Expr
	Pattern Expr
}

func (e *LikeExpr) exprType() string { return "like" }

// StartsWithExpr represents `col STARTS_WITH 'value'`.
type StartsWithExpr struct {
	Column Expr
	Value  Expr
}

func (e *StartsWithExpr) exprType() string { return "starts_with" }

// EndsWithExpr represents `col ENDS_WITH 'value'`.
type EndsWithExpr struct {
	Column Expr
	Value  Expr
}

func (e *EndsWithExpr) exprType() string { return "ends_with" }

// MatchesExpr represents `col MATCHES '/regex/'`.
type MatchesExpr struct {
	Column  Expr
	Pattern Expr
}

func (e *MatchesExpr) exprType() string { return "matches" }

// IsNullExpr represents `col IS NULL` or `col IS NOT NULL`.
type IsNullExpr struct {
	Column Expr
	Not    bool
}

func (e *IsNullExpr) exprType() string { return "is_null" }
