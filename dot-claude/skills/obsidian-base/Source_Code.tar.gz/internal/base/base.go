package base

import (
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

// Base represents a parsed .base file.
type Base struct {
	Name       string
	Path       string // absolute path to .base file
	Filters    *FilterNode
	Formulas   map[string]string
	Properties map[string]PropertyConfig
	Summaries  map[string]string
	Views      []View
	Raw        map[string]any // raw YAML data
}

type PropertyConfig struct {
	DisplayName string `yaml:"displayName"`
}

type View struct {
	Type       string            `yaml:"type"`
	Name       string            `yaml:"name"`
	Limit      int               `yaml:"limit,omitempty"`
	GroupBy    *GroupBy           `yaml:"groupBy,omitempty"`
	Filters    *FilterNode       `yaml:"-"`
	RawFilters any               `yaml:"filters,omitempty"`
	Order      []string          `yaml:"order,omitempty"`
	Sort       []SortEntry       `yaml:"sort,omitempty"`
	Summaries  map[string]string `yaml:"summaries,omitempty"`
	ColumnSize map[string]int    `yaml:"columnSize,omitempty"`
}

type GroupBy struct {
	Property  string `yaml:"property"`
	Direction string `yaml:"direction"`
}

type SortEntry struct {
	Property  string `yaml:"property"`
	Direction string `yaml:"direction"`
}

// FilterNode represents a filter tree node (and/or/not or leaf expression).
type FilterNode struct {
	Type     string        // "and", "or", "not", "leaf"
	Children []*FilterNode // for and/or/not
	Expr     string        // for leaf nodes
}

// Parse reads and parses a .base file.
func Parse(path string) (*Base, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	var raw map[string]any
	if err := yaml.Unmarshal(data, &raw); err != nil {
		return nil, err
	}

	name := strings.TrimSuffix(filepath.Base(path), ".base")

	b := &Base{
		Name:       name,
		Path:       path,
		Formulas:   make(map[string]string),
		Properties: make(map[string]PropertyConfig),
		Summaries:  make(map[string]string),
		Raw:        raw,
	}

	// Parse filters
	if f, ok := raw["filters"]; ok {
		b.Filters = parseFilterNode(f)
	}

	// Parse formulas
	if f, ok := raw["formulas"]; ok {
		if fm, ok := f.(map[string]any); ok {
			for k, v := range fm {
				b.Formulas[k] = toString(v)
			}
		}
	}

	// Parse properties
	if p, ok := raw["properties"]; ok {
		if pm, ok := p.(map[string]any); ok {
			for k, v := range pm {
				pc := PropertyConfig{}
				if vm, ok := v.(map[string]any); ok {
					if dn, ok := vm["displayName"]; ok {
						pc.DisplayName = toString(dn)
					}
				}
				b.Properties[k] = pc
			}
		}
	}

	// Parse summaries
	if s, ok := raw["summaries"]; ok {
		if sm, ok := s.(map[string]any); ok {
			for k, v := range sm {
				b.Summaries[k] = toString(v)
			}
		}
	}

	// Parse views
	if v, ok := raw["views"]; ok {
		if vl, ok := v.([]any); ok {
			for _, item := range vl {
				if vm, ok := item.(map[string]any); ok {
					view := parseView(vm)
					b.Views = append(b.Views, view)
				}
			}
		}
	}

	return b, nil
}

func parseView(m map[string]any) View {
	v := View{
		Summaries:  make(map[string]string),
		ColumnSize: make(map[string]int),
	}

	if t, ok := m["type"]; ok {
		v.Type = toString(t)
	}
	if n, ok := m["name"]; ok {
		v.Name = toString(n)
	}
	if l, ok := m["limit"]; ok {
		if num, ok := l.(int); ok {
			v.Limit = num
		}
	}
	if g, ok := m["groupBy"]; ok {
		if gm, ok := g.(map[string]any); ok {
			gb := &GroupBy{}
			if p, ok := gm["property"]; ok {
				gb.Property = toString(p)
			}
			if d, ok := gm["direction"]; ok {
				gb.Direction = toString(d)
			}
			v.GroupBy = gb
		}
	}
	if f, ok := m["filters"]; ok {
		v.Filters = parseFilterNode(f)
		v.RawFilters = f
	}
	if o, ok := m["order"]; ok {
		if ol, ok := o.([]any); ok {
			for _, item := range ol {
				v.Order = append(v.Order, toString(item))
			}
		}
	}
	if s, ok := m["sort"]; ok {
		if sl, ok := s.([]any); ok {
			for _, item := range sl {
				if sm, ok := item.(map[string]any); ok {
					se := SortEntry{}
					if p, ok := sm["property"]; ok {
						se.Property = toString(p)
					}
					if d, ok := sm["direction"]; ok {
						se.Direction = toString(d)
					}
					v.Sort = append(v.Sort, se)
				}
			}
		}
	}
	if sm, ok := m["summaries"]; ok {
		if smm, ok := sm.(map[string]any); ok {
			for k, val := range smm {
				v.Summaries[k] = toString(val)
			}
		}
	}
	if cs, ok := m["columnSize"]; ok {
		if csm, ok := cs.(map[string]any); ok {
			for k, val := range csm {
				if num, ok := val.(int); ok {
					v.ColumnSize[k] = num
				}
			}
		}
	}

	return v
}

func parseFilterNode(v any) *FilterNode {
	switch val := v.(type) {
	case string:
		return &FilterNode{Type: "leaf", Expr: val}
	case map[string]any:
		if children, ok := val["and"]; ok {
			node := &FilterNode{Type: "and"}
			if list, ok := children.([]any); ok {
				for _, child := range list {
					if cn := parseFilterNode(child); cn != nil {
						node.Children = append(node.Children, cn)
					}
				}
			}
			return node
		}
		if children, ok := val["or"]; ok {
			node := &FilterNode{Type: "or"}
			if list, ok := children.([]any); ok {
				for _, child := range list {
					if cn := parseFilterNode(child); cn != nil {
						node.Children = append(node.Children, cn)
					}
				}
			}
			return node
		}
		if child, ok := val["not"]; ok {
			node := &FilterNode{Type: "not"}
			if list, ok := child.([]any); ok {
				for _, c := range list {
					if cn := parseFilterNode(c); cn != nil {
						node.Children = append(node.Children, cn)
					}
				}
			} else if cn := parseFilterNode(child); cn != nil {
				node.Children = append(node.Children, cn)
			}
			return node
		}
	}
	return nil
}

func toString(v any) string {
	if v == nil {
		return ""
	}
	if s, ok := v.(string); ok {
		return s
	}
	return ""
}

// Serialize writes a Base back to YAML.
func (b *Base) Serialize() ([]byte, error) {
	return yaml.Marshal(b.Raw)
}

// SaveTo writes the base to its file path.
func (b *Base) SaveTo(path string) error {
	data, err := b.Serialize()
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0644)
}
