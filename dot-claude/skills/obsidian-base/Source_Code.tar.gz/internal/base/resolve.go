package base

import (
	"github.com/nihil/obsidian-base/internal/vault"
)

// Resolve returns all notes from the vault that match the base's global filters.
func Resolve(b *Base, v *vault.Vault) []*vault.Note {
	var result []*vault.Note
	for _, note := range v.Notes() {
		if EvalFilter(b.Filters, note, v.Root) {
			result = append(result, note)
		}
	}
	return result
}

// ResolveColumns determines what columns are available for a base.
// It returns file properties, note properties found across matching notes,
// and formula properties.
func ResolveColumns(b *Base, notes []*vault.Note) []ColumnInfo {
	var cols []ColumnInfo

	// file.name is always present
	cols = append(cols, ColumnInfo{Name: "file.name", Type: "string", Source: "file"})

	// Collect all note properties across all matching notes
	propTypes := make(map[string]string)
	for _, note := range notes {
		for k, v := range note.Properties {
			if _, exists := propTypes[k]; !exists {
				propTypes[k] = inferType(v)
			}
		}
	}

	// Add note properties
	for k, t := range propTypes {
		cols = append(cols, ColumnInfo{Name: k, Type: t, Source: "note"})
	}

	// Add formula properties
	for k := range b.Formulas {
		cols = append(cols, ColumnInfo{Name: "formula." + k, Type: "any", Source: "formula"})
	}

	return cols
}

type ColumnInfo struct {
	Name   string `json:"name"`
	Type   string `json:"type"`
	Source string `json:"source"`
}

func inferType(v any) string {
	switch v.(type) {
	case string:
		return "string"
	case int, int64, float64, float32:
		return "number"
	case bool:
		return "boolean"
	case []any, []string:
		return "list"
	case map[string]any:
		return "object"
	default:
		return "string"
	}
}
