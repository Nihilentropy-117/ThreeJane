package base

import (
	"github.com/nihil/obsidian-base/internal/expr"
	"github.com/nihil/obsidian-base/internal/vault"
)

// EvalFilter evaluates a filter tree against a note.
func EvalFilter(node *FilterNode, note *vault.Note, vaultRoot string) bool {
	if node == nil {
		return true
	}

	switch node.Type {
	case "leaf":
		return evalLeafFilter(node.Expr, note, vaultRoot)
	case "and":
		for _, child := range node.Children {
			if !EvalFilter(child, note, vaultRoot) {
				return false
			}
		}
		return true
	case "or":
		for _, child := range node.Children {
			if EvalFilter(child, note, vaultRoot) {
				return true
			}
		}
		return len(node.Children) == 0
	case "not":
		if len(node.Children) > 0 {
			return !EvalFilter(node.Children[0], note, vaultRoot)
		}
		return true
	}
	return true
}

// evalLeafFilter evaluates a single filter expression string against a note.
func evalLeafFilter(expression string, note *vault.Note, vaultRoot string) bool {
	ctx := buildNoteContext(note, vaultRoot)

	val, err := expr.EvalExpression(expression, ctx)
	if err != nil {
		return false
	}
	return val.IsTruthy()
}

// buildNoteContext creates an expression evaluation context from a note.
func buildNoteContext(note *vault.Note, vaultRoot string) *expr.Context {
	ctx := expr.NewContext()

	// Set up file object
	fileVal := expr.FileVal(&expr.FileValue{
		Name:       note.FileName(),
		Basename:   note.FileBasename(),
		Path:       note.RelPath(),
		Folder:     note.FileFolderRel(),
		Ext:        note.FileExt(),
		Size:       note.FileSize(),
		Ctime:      note.FileCtime(),
		Mtime:      note.FileMtime(),
		Tags:       note.Tags(),
		Links:      note.Links(),
		Properties: note.Properties,
	})
	ctx.Set("file", fileVal)

	// Set note properties as top-level variables
	for k, v := range note.Properties {
		ctx.Set(k, expr.GoToValue(v))
	}

	return ctx
}

// BuildNoteContext is the exported version for use by other packages.
func BuildNoteContext(note *vault.Note, vaultRoot string) *expr.Context {
	return buildNoteContext(note, vaultRoot)
}

// FilterToString converts a filter node back to a human-readable string.
func FilterToString(node *FilterNode) string {
	if node == nil {
		return ""
	}
	switch node.Type {
	case "leaf":
		return node.Expr
	case "and":
		parts := make([]string, len(node.Children))
		for i, c := range node.Children {
			parts[i] = FilterToString(c)
		}
		result := ""
		for i, p := range parts {
			if i > 0 {
				result += " AND "
			}
			result += p
		}
		return result
	case "or":
		parts := make([]string, len(node.Children))
		for i, c := range node.Children {
			parts[i] = FilterToString(c)
		}
		result := ""
		for i, p := range parts {
			if i > 0 {
				result += " OR "
			}
			result += p
		}
		return result
	case "not":
		if len(node.Children) > 0 {
			return "NOT " + FilterToString(node.Children[0])
		}
	}
	return ""
}
