package vault

import (
	"strings"

	"gopkg.in/yaml.v3"
)

// ParseFrontmatter splits a markdown file into frontmatter properties and body.
// Returns nil properties if no frontmatter is found.
func ParseFrontmatter(content string) (map[string]any, string) {
	if !strings.HasPrefix(content, "---") {
		return nil, content
	}

	// Find the closing ---
	rest := content[3:]
	// Skip the newline after opening ---
	if len(rest) > 0 && rest[0] == '\n' {
		rest = rest[1:]
	} else if len(rest) > 1 && rest[0] == '\r' && rest[1] == '\n' {
		rest = rest[2:]
	}

	endIdx := strings.Index(rest, "\n---")
	if endIdx == -1 {
		return nil, content
	}

	fmContent := rest[:endIdx]
	body := rest[endIdx+4:] // skip \n---
	// Skip newline after closing ---
	if len(body) > 0 && body[0] == '\n' {
		body = body[1:]
	} else if len(body) > 1 && body[0] == '\r' && body[1] == '\n' {
		body = body[2:]
	}

	props := make(map[string]any)
	if err := yaml.Unmarshal([]byte(fmContent), &props); err != nil {
		return nil, content
	}

	return props, body
}

// WriteFrontmatter serializes properties back into a frontmatter block + body.
func WriteFrontmatter(props map[string]any, body string) string {
	if len(props) == 0 {
		return body
	}

	b, err := yaml.Marshal(props)
	if err != nil {
		return body
	}

	var sb strings.Builder
	sb.WriteString("---\n")
	sb.Write(b)
	sb.WriteString("---\n")
	if body != "" {
		sb.WriteString("\n")
		sb.WriteString(body)
	}
	return sb.String()
}
