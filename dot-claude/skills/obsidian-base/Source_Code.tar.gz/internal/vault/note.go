package vault

import (
	"os"
	"path/filepath"
	"strings"
	"time"
)

type Note struct {
	FilePath   string
	Properties map[string]any
	Body       string
	FileInfo   os.FileInfo
	VaultRoot  string
}

func (n *Note) FileName() string {
	return filepath.Base(n.FilePath)
}

func (n *Note) FileBasename() string {
	name := filepath.Base(n.FilePath)
	return strings.TrimSuffix(name, filepath.Ext(name))
}

func (n *Note) FileFolderRel() string {
	rel, _ := filepath.Rel(n.VaultRoot, filepath.Dir(n.FilePath))
	if rel == "." {
		return ""
	}
	return rel
}

func (n *Note) FileExt() string {
	return filepath.Ext(n.FilePath)
}

func (n *Note) RelPath() string {
	rel, _ := filepath.Rel(n.VaultRoot, n.FilePath)
	return rel
}

func (n *Note) FileSize() int64 {
	if n.FileInfo != nil {
		return n.FileInfo.Size()
	}
	return 0
}

func (n *Note) FileMtime() time.Time {
	if n.FileInfo != nil {
		return n.FileInfo.ModTime()
	}
	return time.Time{}
}

func (n *Note) FileCtime() time.Time {
	// On most systems ctime == mtime; platform-specific ctime requires syscall
	return n.FileMtime()
}

// Tags returns all tags: from frontmatter tags field + inline #tags in body.
func (n *Note) Tags() []string {
	var tags []string

	// Frontmatter tags
	if t, ok := n.Properties["tags"]; ok {
		switch v := t.(type) {
		case []any:
			for _, item := range v {
				if s, ok := item.(string); ok {
					tags = append(tags, s)
				}
			}
		case []string:
			tags = append(tags, v...)
		case string:
			// Single tag as string
			tags = append(tags, v)
		}
	}

	// Inline tags from body
	tags = append(tags, extractInlineTags(n.Body)...)
	return uniqueStrings(tags)
}

// Links returns all [[wiki links]] found in frontmatter values and body.
func (n *Note) Links() []string {
	var links []string
	// From body
	links = append(links, extractWikiLinks(n.Body)...)
	// From frontmatter
	for _, v := range n.Properties {
		if s, ok := v.(string); ok {
			links = append(links, extractWikiLinks(s)...)
		}
	}
	return uniqueStrings(links)
}

// GetProperty resolves a property reference for this note.
func (n *Note) GetProperty(name string) any {
	if strings.HasPrefix(name, "file.") {
		return n.getFileProperty(name)
	}
	// Strip optional "note." prefix
	key := strings.TrimPrefix(name, "note.")
	if v, ok := n.Properties[key]; ok {
		return v
	}
	return nil
}

func (n *Note) getFileProperty(name string) any {
	switch name {
	case "file.name":
		return n.FileBasename()
	case "file.path":
		return n.RelPath()
	case "file.folder":
		return n.FileFolderRel()
	case "file.ext":
		return n.FileExt()
	case "file.size":
		return n.FileSize()
	case "file.mtime":
		return n.FileMtime()
	case "file.ctime":
		return n.FileCtime()
	case "file.tags":
		return n.Tags()
	case "file.links":
		return n.Links()
	default:
		return nil
	}
}

// ToRow produces a map of all properties for SQL result output.
func (n *Note) ToRow(columns []string) map[string]any {
	row := make(map[string]any, len(columns))
	for _, col := range columns {
		row[col] = n.GetProperty(col)
	}
	return row
}

func extractInlineTags(body string) []string {
	var tags []string
	i := 0
	for i < len(body) {
		if body[i] == '#' {
			// Must be start of line or preceded by whitespace
			if i > 0 && body[i-1] != ' ' && body[i-1] != '\t' && body[i-1] != '\n' {
				i++
				continue
			}
			j := i + 1
			for j < len(body) && isTagChar(body[j]) {
				j++
			}
			if j > i+1 {
				tag := body[i+1 : j]
				// Skip markdown headings (## etc)
				if !strings.HasPrefix(tag, "#") {
					tags = append(tags, tag)
				}
			}
			i = j
		} else {
			i++
		}
	}
	return tags
}

func isTagChar(b byte) bool {
	return (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9') || b == '_' || b == '-' || b == '/'
}

func extractWikiLinks(s string) []string {
	var links []string
	for {
		idx := strings.Index(s, "[[")
		if idx == -1 {
			break
		}
		s = s[idx+2:]
		end := strings.Index(s, "]]")
		if end == -1 {
			break
		}
		link := s[:end]
		// Handle display text [[target|display]]
		if pipe := strings.Index(link, "|"); pipe != -1 {
			link = link[:pipe]
		}
		links = append(links, link)
		s = s[end+2:]
	}
	return links
}

func uniqueStrings(ss []string) []string {
	seen := make(map[string]bool, len(ss))
	var result []string
	for _, s := range ss {
		if !seen[s] {
			seen[s] = true
			result = append(result, s)
		}
	}
	return result
}
