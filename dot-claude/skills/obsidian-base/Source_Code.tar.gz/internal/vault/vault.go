package vault

import (
	"os"
	"path/filepath"
	"strings"
	"sync"
)

type Vault struct {
	Root      string
	notes     []*Note
	bases     []string
	notesOnce sync.Once
	basesOnce sync.Once
}

func Open(root string) (*Vault, error) {
	info, err := os.Stat(root)
	if err != nil {
		return nil, err
	}
	if !info.IsDir() {
		return nil, &os.PathError{Op: "open", Path: root, Err: os.ErrInvalid}
	}
	abs, err := filepath.Abs(root)
	if err != nil {
		return nil, err
	}
	return &Vault{Root: abs}, nil
}

func (v *Vault) Notes() []*Note {
	v.notesOnce.Do(func() {
		v.notes = v.scanNotes()
	})
	return v.notes
}

func (v *Vault) BaseFiles() []string {
	v.basesOnce.Do(func() {
		v.bases = v.scanBases()
	})
	return v.bases
}

func (v *Vault) FindBase(name string) string {
	// Normalize: strip .base extension if provided
	name = strings.TrimSuffix(name, ".base")
	lower := strings.ToLower(name)

	for _, bp := range v.BaseFiles() {
		base := filepath.Base(bp)
		baseName := strings.TrimSuffix(base, ".base")
		if strings.EqualFold(baseName, lower) {
			return bp
		}
	}
	return ""
}

func (v *Vault) BaseNames() []string {
	var names []string
	for _, bp := range v.BaseFiles() {
		base := filepath.Base(bp)
		names = append(names, strings.TrimSuffix(base, ".base"))
	}
	return names
}

func (v *Vault) scanBases() []string {
	var bases []string
	filepath.WalkDir(v.Root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() {
			name := d.Name()
			if name == ".obsidian" || name == ".git" || name == ".trash" || name == "node_modules" {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasSuffix(path, ".base") {
			bases = append(bases, path)
		}
		return nil
	})
	return bases
}

func (v *Vault) scanNotes() []*Note {
	var paths []string
	filepath.WalkDir(v.Root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		if d.IsDir() {
			name := d.Name()
			if name == ".obsidian" || name == ".git" || name == ".trash" || name == "node_modules" {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasSuffix(path, ".md") {
			paths = append(paths, path)
		}
		return nil
	})

	// Parse concurrently
	notes := make([]*Note, len(paths))
	var wg sync.WaitGroup
	sem := make(chan struct{}, 32) // worker pool size

	for i, p := range paths {
		wg.Add(1)
		go func(idx int, path string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			note, err := v.parseNote(path)
			if err == nil {
				notes[idx] = note
			}
		}(i, p)
	}
	wg.Wait()

	// Filter out nils (parse failures)
	var result []*Note
	for _, n := range notes {
		if n != nil {
			result = append(result, n)
		}
	}
	return result
}

func (v *Vault) parseNote(path string) (*Note, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}

	info, err := os.Stat(path)
	if err != nil {
		return nil, err
	}

	props, body := ParseFrontmatter(string(data))
	if props == nil {
		props = make(map[string]any)
	}

	return &Note{
		FilePath:   path,
		Properties: props,
		Body:       body,
		FileInfo:   info,
		VaultRoot:  v.Root,
	}, nil
}
