package errors

import (
	"encoding/json"
	"fmt"
	"os"
)

type Code string

const (
	BaseNotFound    Code = "base_not_found"
	ParseError      Code = "parse_error"
	ColumnNotFound  Code = "column_not_found"
	TypeError       Code = "type_error"
	FilterMismatch  Code = "filter_mismatch"
	VaultNotFound   Code = "vault_not_found"
	WriteError      Code = "write_error"
	CircularFormula Code = "circular_formula"
)

type Error struct {
	Code       Code   `json:"error"`
	Message    string `json:"message"`
	Suggestion string `json:"suggestion,omitempty"`
}

func (e *Error) Error() string {
	return e.Message
}

func New(code Code, message string) *Error {
	return &Error{Code: code, Message: message}
}

func WithSuggestion(code Code, message, suggestion string) *Error {
	return &Error{Code: code, Message: message, Suggestion: suggestion}
}

func Newf(code Code, format string, args ...any) *Error {
	return &Error{Code: code, Message: fmt.Sprintf(format, args...)}
}

func PrintAndExit(err *Error) {
	b, _ := json.Marshal(err)
	fmt.Fprintln(os.Stderr, string(b))
	os.Exit(1)
}

func Print(err *Error) {
	b, _ := json.Marshal(err)
	fmt.Fprintln(os.Stderr, string(b))
}
